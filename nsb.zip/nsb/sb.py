# -*- coding: utf-8 -*-
from thrift.transport import TTransport
from thrift.transport import TSocket
from thrift.transport import THttpClient
from thrift.protocol import TCompactProtocol
#==========ALLEN_BOT THRIFY===========#
#from urllib import urlretrieve
from urllib.request import urlretrieve
from urllib.request import urlopen
from urllib.parse import urlencode,quote,urlparse,parse_qs,parse_qsl,urlunparse,urlsplit,urljoin,urldefrag,quote_plus,unquote
from akad.ttypes import Message
from line import *
from line import LineThrift
from line import client
from datetime import datetime
from bs4 import BeautifulSoup
from time import sleep
from gtts import gTTS
from io import StringIO
import urllib.request
import urllib.parse
import ast,json
import re
import time
import sys
import timeit
import random
import codecs
import threading
import glob
import tempfile
import urllib, urllib3
import os,six
import wikipedia
import requests
import html5lib
import urbandictionary as ud
import multiprocessing
import subprocess
import pafy
try:
    import simplejson as json
except ImportError:
    import json

print ("#=====================================DATE BOTS=================================#")
with open('token.json', 'r') as fp:
    akun = json.load(fp)

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)


#if akun['token1'] == "":
#    cl = LineClient()
#else:
#  try:
#    cl = LineClient(authToken=akun['token1'])
#  except Exception as E:
#    E = str(E)
#    if "reason=None" in E:
#      print (E)
#      time.sleep(60)
#      restart_program()
if akun['token1'] == "Ez4Hvn2nd4iUjT9Ggize.kWo+HuJdnwhsz13oKAS2dG.L1tycT7OgE10KbualJDogi+WW1EHIFfJf7t5FTb8WKs=":
    cl = LineClient()
else:
    cl=LineClient(authToken=akun['token1'])
      

KAC=[cl]
mid = cl.getProfile().mid
print ("Main BOT " + mid+ " \nToken: "+cl.authToken)
akun['token1'] = cl.authToken
with open('token.json', 'w') as fp:
    json.dump(akun, fp, sort_keys=True, indent=4)
    
Bots=[mid]
wbanlist = []
inviting = False
kick = False
profile = cl.getProfile()
profile.displayName = profile.displayName
profile.statusMessage = profile.statusMessage
profile.pictureStatus = profile.pictureStatus

strt = datetime.now()
wbanlist = []
gambar = ["http://i0.kym-cdn.com/photos/images/original/001/217/729/f9a.jpg","http://i0.kym-cdn.com/photos/images/original/000/919/085/7b6.png","http://i0.kym-cdn.com/photos/images/original/000/616/565/35a.jpg","http://i0.kym-cdn.com/photos/images/original/000/632/711/1b0.png","http://i0.kym-cdn.com/photos/images/original/001/229/218/268.gif","http://i0.kym-cdn.com/photos/images/original/001/248/160/6d4.png","http://i0.kym-cdn.com/photos/images/original/001/225/905/18c.jpg","http://i0.kym-cdn.com/photos/images/original/001/226/694/857.jpg","http://i0.kym-cdn.com/photos/images/original/001/221/672/5f1.jpg","http://www.imgion.com/images/01/Youre-always-seems-to-care.jpg","http://www.imgion.com/images/01/YOure-Always-Near-.jpg","http://www.imgion.com/images/01/YOur-Beauty-Is-Like-.jpg","http://www.imgion.com/images/01/YOur-Angel-Will-Always-.jpg","http://www.imgion.com/images/01/You-will-be-My-Companion.gif","http://www.imgion.com/images/01/YOu-here-You-Are-.jpg","http://www.imgion.com/images/01/You-Cant-Mad-.jpg","http://www.imgion.com/images/01/You-Are-The-Best-Thing.gif","http://www.imgion.com/images/01/You-Are-The-Best-Friend-.png","http://www.imgion.com/images/01/Usb-With-Wifi-.jpg","http://www.imgion.com/images/01/Watch-This-Thriller-.jpg","http://www.imgion.com/images/01/You-Shit-Yourself-.jpg","http://www.imgion.com/images/01/Youre-wornd-I-Hate-you-.jpg","http://www.imgion.com/images/01/YOu-Dont-Say-.jpg","http://www.imgion.com/images/01/Where-You-Going-.jpg","http://www.imgion.com/images/01/What-a-jooke-.jpg","http://www.imgion.com/images/01/What-The-Face-.jpg"]
with open('settingan.json', 'r') as fp:
    periksa = json.load(fp)
with open('command.json', 'r') as fp:
    command = json.load(fp)
with open('sider.json', 'r') as fp:
    sider = json.load(fp)
with open('respon.json', 'r') as fp:
    respon = json.load(fp)
    
setTime = {}
setTime = sider['setTime']

ch = LineChannel(cl)
print ("#============================THB BOTS STARTING============================#")

def sendMessageWithMention(self, to, text='', dataMid=[]):
        arr = []
        list_text=''
        if '[list]' in text.lower():
            i=0
            for l in dataMid:
                list_text+='\n@[list-'+str(i)+']'
                i=i+1
            text=text.replace('[list]', list_text)
        elif '[list-' in text.lower():
            text=text
        else:
            i=0
            for l in dataMid:
                list_text+=' @[list-'+str(i)+']'
                i=i+1
            text=text+list_text
        i=0
        for l in dataMid:
            mid=l
            name='@[list-'+str(i)+']'
            ln_text=text.replace('\n',' ')
            if ln_text.find(name):
                line_s=int( ln_text.index(name) )
                line_e=(int(line_s)+int( len(name) ))
            arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
            arr.append(arrData)
            i=i+1
        contentMetadata={'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        return
        cl.sendMessage(to, text, contentMetadata)

#def sendText(self, Tomid, text):
#    msg = Message()
#    msg.to = Tomid
#    msg.text = text

#    return self.Talk.client.sendMessage(0, msg)

def sendMessage(to, text, contentMetadata={}, contentType=0):
    mes = Message()
    mes.to, mes.from_ = to, profile.mid
    mes.text = text
    mes.contentType, mes.contentMetadata = contentType, contentMetadata
    if to not in messageReq:
        messageReq[to] = -1
    messageReq[to] += 1

def MENTION(to, nama):
    zx = ""
    zxc = ""
    nm = nama
    for x in nm:
        pesan = ''
        pesan2 = pesan+"@a\n"
        xlen = str(len(zxc))
        xlen2 = str(len(zxc)+len(pesan2)-1)
        zx += """{"S":"""+json.dumps(xlen)+""","E":"""+json.dumps(xlen2)+""","M":"""+json.dumps(x)+"},"""
        
        zxc += pesan2
    zx = (zx[:int(len(zx)-1)])
    msg = Message()
    msg.to = to
    msg.text = zxc
    msg.contentMetadata = {'MENTION':'{"MENTIONEES":['+zx+']}','EMTVER':'4'}
    try:
        kk.sendMessage(msg.to,msg.text,msg.contentMetadata)
        wb.sendMessage(msg.to,msg.text,msg.contentMetadata)
        wb1.sendMessage(msg.to,msg.text,msg.contentMetadata)
        wb2.sendMessage(msg.to,msg.text,msg.contentMetadata)
        wb3.sendMessage(msg.to,msg.text,msg.contentMetadata)
    except Exception as e:
        print (e)
def Tagall1(to, nama):
    aa = ""
    bb = ""
    strt = int(19)
    akh = int(19)
    nm = nama
    for mm in nm:
      akh = akh + 2
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 6
      akh = akh + 4
      bb += "✪ @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "「Mention All」   \n"+bb + "    「 Total: " + str(len(nm)) +  " Mention 」"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    try:
       cl.sendMessage(msg.to,msg.text,msg.contentMetadata)
    except Exception as error:
       print(error)
def Tagall2(to, nama):
    aa = ""
    bb = ""
    strt = int(19)
    akh = int(19)
    nm = nama
    for mm in nm:
      akh = akh + 2
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 6
      akh = akh + 4
      bb += "✪ @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "「Mention All」   \n"+bb + "    「 Total: " + str(len(nm)) +  " Mention 」"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    try:
       wb.sendMessage(msg.to,msg.text,msg.contentMetadata)
    except Exception as error:
       print(error)
def Tagall3(to, nama):
    aa = ""
    bb = ""
    strt = int(19)
    akh = int(19)
    nm = nama
    for mm in nm:
      akh = akh + 2
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 6
      akh = akh + 4
      bb += "✪ @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "「Mention All」   \n"+bb + "    「 Total: " + str(len(nm)) +  " Mention 」"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    try:
       wb1.sendMessage(msg.to,msg.text,msg.contentMetadata)
    except Exception as error:
       print(error)
def Tagall4(to, nama):
    aa = ""
    bb = ""
    strt = int(19)
    akh = int(19)
    nm = nama
    for mm in nm:
      akh = akh + 2
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 6
      akh = akh + 4
      bb += "✪ @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "「Mention All」   \n"+bb + "    「 Total: " + str(len(nm)) +  " Mention 」"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    try:
       wb2.sendMessage(msg.to,msg.text,msg.contentMetadata)
    except Exception as error:
       print(error)
def Tagall5(to, nama):
    aa = ""
    bb = ""
    strt = int(19)
    akh = int(19)
    nm = nama
    for mm in nm:
      akh = akh + 2
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 6
      akh = akh + 4
      bb += "✪ @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "「Mention All」   \n"+bb + "    「 Total: " + str(len(nm)) +  " Mention 」"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    try:
       wb3.sendMessage(msg.to,msg.text,msg.contentMetadata)
    except Exception as error:
       print(error)
'''

'''
cl.log("Channel Access Token : " + str(ch.channelAccessToken))
print("#==================================STARTING BOTS===================================#")
agent = {'user-Agent': "Mozilla/4.0(compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50/27; .NET CLR 3.0.04506.0)"} 

def translate(to_translate, to_language="auto", language="auto"):
    base_link="http://translate.google.com/m?hl=%s&sl=%s&q=%s"
    if(six.PY2):
        link = base_link % (to_language, language, urllib.pathname2url(to_translate))
        request = urllib2.Request(link, headers=agent)
        page = urllib2.urlopen(request).read()
    else:
        link = base_link % (to_language, language, urllib.parse.quote(to_translate))
        request = urllib.request.Request(link, headers=agent)
        page = urllib.request.urlopen(request).read().decode('utf-8')
    expr = r'class="t0">(.*?)<'
    result = re.findall(expr,page)
    if(len(result)==0):
        return("")
    return(result[0])

def yt(query):
    with requests.session() as s:
         isi = []
         if query == "":
             query = "Night Core Aditya K-Music"   
         s.headers['user-agent'] = 'Mozilla/5.0'
         url    = 'http://www.youtube.com/results'
         params = {'search_query': query}
         r    = s.get(url, params=params)
         soup = BeautifulSoup(r.content, 'html5lib')
         for a in soup.select('.yt-lockup-title > a[title]'):
         #for a in soup.select('.yt-uix-tile-link'):
            if '&list=' not in a['href']:
                if 'watch?v' in a['href']:
                    b = a['href'].replace('watch?v=', '')
                    isi += ['youtu.be' + b]
         return isi

def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     #If the Current Version of Python is 3.0 or above
        import urllib.request    #urllib library for Extracting web pages
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib.request.Request(url, headers = headers)
            resp = urllib.request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        #If the Current Version of Python is 2.x
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"


#Finding 'Next Image' from the given raw page
def _images_get_next_item(s):
    start_line = s.find('rg_di')
    if start_line == -1:    #If no links are found then give an error!
        end_quote = 0
        link = "no_links"
        return link, end_quote
    else:
        start_line = s.find('"class="rg_meta"')
        start_content = s.find('"ou"',start_line+70)
        end_content = s.find(',"ow"',start_content-70)
        content_raw = str(s[start_content+6:end_content-1])
        return content_raw, end_content


#Getting all links with the help of '_images_get_next_image'
def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      #Append all the links in the list named 'Links'
            page = page[end_content:]
    return items

def autolike():
     like = 1000+periksa['like']
     koment = periksa['comment']
     hasil = cl.getFeed(postLimit=20)
     for zx in range(0,20):
        if hasil['result']['feeds'][zx]['post']['postInfo']['liked'] == False:
          try:    
            cl.like(hasil['result']['feeds'][zx]['post']['userInfo']['mid'],hasil['result']['feeds'][zx]['post']['postInfo']['postId'],likeType=like)
            cl.comment(hasil['result']['feeds'][zx]['post']['userInfo']['mid'],hasil['result']['feeds'][zx]['post']['postInfo']['postId'],koment+"")
            print ("Liked mid: " + str(hasil['result']['feeds'][zx]['post']['userInfo']['mid']))
          except Exception as E:
            print (E)
        else:
            print ("Already Liked")
def resetchat():
    while True:
        try:
            if periksa['autolike'] == True:
              autolike()
              time.sleep(300)
              autolike()
            else:
                pass
            kk.removeAllMessages(mid)
            print ("reset")
            with open('settingan.json', 'w') as fp:
                json.dump(periksa, fp, sort_keys=True, indent=4)
            time.sleep(400)
        except:
            pass
thread2 = threading.Thread(target=resetchat)
thread2.daemon = True
thread2.start()

while True:
 try:
  Ops = cl.fetchOps(cl.revision, 50)    
  for op in Ops:
    if op.type != 0:
        cl.revision = max(cl.revision, op.revision)
                
        texthelp = command['text']
        hCurl= command['curl']
        hOurl= command['ourl']
        hKick = command['kick']
        hKill = command['kill']
        hRejoin = command['mybot']
        hBye = command['bye']
        hMe = command['me']
        hCancel = command['cancel']
        hNuke = command['nuke']
        hTagall = command['tagall']
        hHelp = command['help']
        hSpeed = command['speed']
        rname = respon['rname']
        sname = respon['sname']
        admins = periksa['wl']
        ban = periksa['banlist']
        helpMessage ="\
\n ✍ŤẸÃϻ Ж ĤÃЌβỖŤ✈\n\n\
\n⊰❉⊱ responsename\
\n⊰❉⊱ sname\
\n⊰❉⊱ [rname] help\
\n\nCOMMAND IN KICKER\
\n\nThanks to:\
\nDate\
"
        if op.type == 5:
            if periksa['autoadd'] == True:
                cl.findAndAddContactsByMid(op.param1)
                if (periksa["message"] in [""," ","\n",None]):
                    pass
                else:
                    cl.sendMessage(op.param1,str(periksa["message"]))
            else:
                pass
#***Kick Talker by Date
            if msg.toType == 2:
                if msg.to in str(open('tbanlist.txt').read()):
                    cl.sendMessage(msg.to, "Please shuut up...")
                    try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(msg.to, [msg.to])
                    except:
                        pass
        if op.type == 11:
          if op.param1 in periksa["lockqr"]:
             if op.param2 not in Bots and op.param2 not in periksa["wl"]:
                X = cl.getGroup(op.param1)
                if X.preventedJoinByTicket == False:
                  X.preventedJoinByTicket = True
                  kicker=random.choice(KAC)
                  kicker.updateGroup(X)
                  if op.param2 in periksa["banlist"]:
                    kicker=random.choice(KAC)
                    kicker.kickoutFromGroup(op.param1,[op.param2])
                  else:
                    periksa["banlist"][op.param2] = True
                    with open('settingan.json', 'w') as fp:
                      json.dump(periksa, fp, sort_keys=True, indent=4)
          if op.param1 in periksa["gname"]:
              group = cl.getGroup(op.param1)
              try:
                  G = cl.getGroup(op.param1)
              except:
                  pass
              G.name = periksa['proname'][op.param1]
              try:
                  cl.updateGroup(G)
              except:
                  pass
              if op.param2 not in Bots and op.param2 not in periksa["wl"]:
                  try:
                      kicker=random.choice(KAC)
                      kicker.kickoutFromGroup(op.param1,[op.param2])
                  except:
                      try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[op.param2])
                      except:
                          cl.kickoutFromGroup(op.param1,[op.param2])
              else:
                  periksa["banlist"][op.param2] = True
                  with open('settingan.json', 'w') as fp:
                      json.dump(periksa, fp, sort_keys=True, indent=4)
                      
          if op.param1 in periksa["picon"]:
              group = cl.getGroup(op.param1)
              try:
                  G = group.pictureStatus
              except:
                  pass
              if op.param2 not in Bots and op.param2 not in periksa["wl"]:
                  try:
                     kicker=random.choice(KAC)
                     kicker.kickoutFromGroup(op.param1,[op.param2])
                  except:
                      try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[op.param2])
                      except:
                          cl.kickoutFromGroup(op.param1,[op.param2])
              else:
                  periksa["banlist"][op.param2] = True
                  with open('settingan.json', 'w') as fp:
                      json.dump(periksa, fp, sort_keys=True, indent=4)
                      
        if op.type == 17:
           if op.param1 in periksa["pjoin"]:
               if op.param2 not in Bots and op.param2 not in periksa["wl"]:
                   random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
        if op.type == 17:
          if op.param1 in periksa["autopurge"]:
            G = cl.getGroup(op.param1)
            if G is None:
                pass
            else:
                gMembMids = [contact.mid for contact in G.members]
                matched_list = []
                for tag in periksa["banlist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                if matched_list == []:
                        pass
                for jj in matched_list:
                    try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(op.param1,[jj])
                    except:
                      try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[jj])
                      except:
                            cl.kickoutFromGroup(op.param1,[jj])

        if op.type == 13:
            if mid in op.param3:
              if periksa["autojoin"] == "wl":
                if op.param2 in periksa["wl"]:
                  cl.acceptGroupInvitation(op.param1)
                else:
                    if periksa['autorejc'] == True:
                        cl.rejectGroupInvitation(op.param1)
                    else:
                        pass
              elif periksa["autojoin"] == "all":
                  cl.acceptGroupInvitation(op.param1)
              else:
                  if periksa['autorejc'] == True:
                        cl.rejectGroupInvitation(op.param1)
                  else:
                        pass
            
            else:
                if op.param2 not in Bots and op.param2 not in periksa["wl"]:
                  group_id=op.param1
                  if group_id in periksa["autocancel"]:
                    group = cl.getGroup(op.param1)
                    if group.invitee is None:
                       pass
                    else:
                        gInviMids = [contact.mid for contact in group.invitee]
                        try:
                            kicker=random.choice(KAC)
                            kicker.cancelGroupInvitation(op.param1, gInviMids)
                        except:
                            try:
                                kicker=random.choice(KAC)
                                kicker.cancelGroupInvitation(op.param1, gInviMids)
                            except:
                                cl.cancelGroupInvitation(op.param1, gInviMids)
                                
                if op.param1 in periksa["autopurge"]:        
                    Inviter = op.param3.replace("",',')
                    InviterX = Inviter.split(",")
                    matched_list = []
                    for tag in periksa["banlist"]:
                        matched_list+=filter(lambda str: str == tag, InviterX)
                    if matched_list == []:
                        pass
                    else:
                        kk.cancelGroupInvitation(op.param1, matched_list)
            
        if op.type == 19:
            if op.param1 in periksa["protect"]:
                if op.param2 not in Bots and op.param2 not in periksa['wl']:
                    try:
                        kk.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            kicker=random.choice(KAC)
                            kicker.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                try:
                        kicker=random.choice(KAC)
                        kicker.inviteIntoGroup(op.param1,[op.param3])
                except:
                        try:
                            wb.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            cl.inviteIntoGroup(op.param1,[op.param3])
                if op.param2 in periksa["banlist"]:
                        pass
                elif op.param2 in periksa["wl"]:
                        pass
                elif op.param2 in Bots:
                    pass
                else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)
                   
            if op.param3 in mid: #==========cl
                if op.param2 in Bots:
                    pass
                else:
                    try:
                        kk.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            wb.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                wb1.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    wb2.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    try:
                                        wb3.kickoutFromGroup(op.param1,[op.param2])
                                    except:
                                        pass
                try:
                    G = kk.getGroup(op.param1)
                except:
                    try:
                        G = wb.getGroup(op.param1)
                    except:
                        try:
                            G = wb1.getGroup(op.param1)
                        except:
                            try:
                                G = wb2.getGroup(op.param1)
                            except:
                                try:
                                    G = wb3.getGroup(op.param1)
                                except:
                                    pass
                if G.preventedJoinByTicket == True:
                    G.preventedJoinByTicket = False
                    try:
                        kk.updateGroup(G)
                    except:
                        try:
                            wb.updateGroup(G)
                        except:
                            try:
                                wb1.updateGroup(G)
                            except:
                                try:
                                    wb2.updateGroup(G)
                                except:
                                    try:
                                        wb3.updateGroup(G)
                                    except:
                                        pass
                else:
                    pass
                try:
                    Ti = kk.reissueGroupTicket(op.param1)
                except:
                    try:
                       Ti = wb.reissueGroupTicket(op.param1)
                    except:
                        try:
                            Ti = wb1.reissueGroupTicket(op.param1)
                        except:
                            try:
                                Ti = wb2.reissueGroupTicket(op.param1)
                            except:
                                try:
                                    Ti = wb3.reissueGroupTicket(op.param1)
                                except:
                                    pass
                try:
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = cl.getGroup(op.param1)
                    G.preventedJoinByTicket = True
                    cl.updateGroup(G)
                    Ti = cl.reissueGroupTicket(op.param1)
                    if op.param2 in periksa["banlist"]:
                        pass
                    elif op.param2 in periksa["wl"]:
                        pass
                    elif op.param2 in Bots:
                        pass
                    else:
                        periksa["banlist"][op.param2] = True
                except:
                    pass

        if op.type == 26:
            msg = op.message
            if msg.toType == 0:
                msg.to = msg._from
                if msg.from_ == "u269dbb5d2d5e374a786287bc782ce30b":
                    if "join:" in msg.text:
                        list_ = msg.text.split(":")
                        try:
                            cl.acceptGroupInvitationByTicket(list_[1],list_[2])
                            X = cl.getGroup(list_[1])
                            X.preventedJoinByTicket = True
                        except:
                            cl.sendText(msg.to,"error")
            #if msg.text is None:
            #    pass
            elif 'MENTION' in msg.contentMetadata.keys()!= None:
                if periksa["mention2"] == True:
                    if periksa["mention2"] == True:
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if mention['M'] == mid:
                                xname = cl.getContact(msg._from).displayName
                                xlen = str(len(xname)+1)
                                msg.contentType = 0
                                msg.text = "@"+xname+" "
                                msg.contentMetadata = {'MENTION':'{"MENTIONEES":[{"S":"0","E":'+json.dumps(xlen)+',"M":'+json.dumps(msg._from)+'}]}','EMTVER':'4'}
                                try:
                                    image = cl.getContact(msg._from)
                                    cl.sendMessage(msg.to,image.displayName + periksa["respon"])
                                    msg.contentMetadata = {'mid': msg._from}
                                    cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+image.pictureStatus)
                                    cl.sendMessage(msg.to,'',msg.contentMetadata,13)
                                    #kk.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+image.pictureStatus)
                                except Exception as e:
                                    print (e)
        if op.type == 55:
            try:
                if op.param1 in sider['readPoint']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in sider['readMember'][op.param1]:
                        pass
                    else:
                        sider['readMember'][op.param1] += "\n╠・" + Name
                else:
                    cl.sendMessage
            except:
                pass
				
        if op.type == 55:
                try:
                    if cctv['cyduk'][op.param1]==True:
                        if op.param1 in cctv['point']:
                            Name = client.getContact(op.param2).displayName
                            if Name in cctv['sidermem'][op.param1]:
                                pass
                            else:
                                cctv['sidermem'][op.param1] += "\n~ " + Name
                                zxn=["Hey Jangan sider"," Jangan sider ","Halo ayo kita ngobrol","Turun kak ikut chat","mojok yu","sider jones","Ciyyee yang lagi ngintip","Hai Kang galau","Hai idola"]
                                say = random.choice(zxn) +" "+ Name
                                client.sendMessage(op.param1, say)
                                summon(op.param1,[op.param2])
                        else:
                            pass
                    else:
                        pass
                except:
                    pass
        else:
            pass				

        if op.type == 26:
            msg = op.message
            if periksa["alwayRead"] == True:
                if msg.toType == 0:
                    cl.sendChatChecked(msg.to,msg.id)
                else:
                    cl.sendChatChecked(msg.to,msg.id)

        if op.type == 25:
            msg = op.message
            if msg.contentType == 13:
                global inviting
                global info
                global kick
                if inviting:
                    inviting = False
                    try:
                        cl.findAndAddContactsByMid(msg.contentMetadata["mid"])
                        cl.inviteIntoGroup(msg.to,[msg.contentMetadata["mid"]])
                    except:
                        pass
#============================KICK
                if kick:
                    kick = False
                    try:
                        #cl.findAndAddContactsByMid(msg.contentMetadata["mid"])
                        cl.kickoutFromGroup(msg.to,[msg.contentMetadata["mid"]])
                    except:
                        pass
            
        if op.type == 26:
            msg = op.message
            if msg.text:
                if msg.text.lower().lstrip().rstrip() in wbanlist:
                    if msg.text not in Bots and msg.text not in periksa['wl']:
                        try:
                            kicker=random.choice(KAC)
                            kicker.kickoutFromGroup(msg.to,[msg._from])
                        except:
                            cl.kickoutFromGroup(msg.to,[msg._from])
                    else:
                        pass
                    
        if op.type == 26:
            msg = op.message
            pesan = msg.text
            
            if periksa['mimic'] == True:
                if msg._from in periksa['tmimic']:
                    if msg.text.lower() not in helpMessage:
                        cl.sendMessage(msg)
                else:
                    pass
            else:
                pass
        if op.type == 25: #disini :v
            msg = op.message
            #print (msg)
            pesan = msg.text
            if msg.contentType == 1:
                if msg.to in periksa['me']:
                   xpath = cl.downloadObjectMsg(msg.id)
                   cl.updateProfilePicture(xpath)
                   cl.sendMessage(msg.to, "Done")
                   del periksa['me'][msg.to]
                   with open('settingan.json', 'w') as fp:
                      json.dump(periksa, fp, sort_keys=True, indent=4)
                   
            if msg.contentType == 13:
               if msg.to in periksa["addbanmode"]:
                  if msg.contentMetadata["mid"] in periksa["banlist"]:
                     cl.sendMessage(msg.to, "contact is already in blacklist")
                  elif msg.contentMetadata["mid"] in periksa["wl"]:
                            cl.sendMessage(msg.to,"can't banned whitelist")
                  else:
                        periksa["banlist"][msg.contentMetadata["mid"]] = True
                        with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                        cl.sendMessage(msg.to, "Succes added to banlist")
               elif msg.to in periksa["delbanmode"]:
                   if msg.contentMetadata["mid"] in periksa["banlist"]:
                        del periksa["banlist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Succes deleted from banlist")
                        with open('settingan.json', 'w') as fp:
                            json.dump(periksa, fp, sort_keys=True, indent=4)
                   else:
                        cl.sendMessage(msg.to,"Not in banlist")
              
               elif msg.to in periksa["addwl"]:
                   if msg.contentMetadata["mid"] in periksa["wl"]:
                      cl.sendMessage(msg.to, "User is ready in whitelist")
                   else:
                        periksa["wl"][msg.contentMetadata["mid"]] = True
                        with open('settingan.json', 'w') as fp:
                              json.dump(periksa, fp, sort_keys=True, indent=4)
                        cl.sendMessage(msg.to, "Succes added to whitelist")
               elif msg.to in periksa["delwl"]:
                   if msg.contentMetadata["mid"] in periksa["wl"]:
                        del periksa["wl"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Succes deleted in whitelist")
                        with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                   else:
                        cl.sendMessage(msg.to,"User not in whitelist")
               elif msg.to in periksa["addtarget"]:
                   if msg.contentMetadata["mid"] in periksa["target"]:
                      cl.sendMessage(msg.to, "User is ready in whitelist")
                   else:
                        periksa["target"][msg.contentMetadata["mid"]] = True
                        with open('settingan.json', 'w') as fp:
                              json.dump(periksa, fp, sort_keys=True, indent=4)
                        cl.sendMessage(msg.to, "Succes added to target")
               elif msg.to in periksa["deltarget"]:
                   if msg.contentMetadata["mid"] in periksa["target"]:
                        del periksa["target"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Succes deleted from target list")
                        with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                   else:
                        cl.sendMessage(msg.to,"User not in target list")
               elif msg.to in periksa["gift2"]:
                      target = msg.contentMetadata["mid"]
                      lol = msg.to
                      msg.contentType = 9
                      msg.contentMetadata = { 'STKPKGID':'3172',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'2'}
                      msg.to = target
                      msg.text == None
                      for zx in range(0,periksa['gift2jumlah']):

                        cl.sendMessage(msg.to,msg.text,msg.contentMetadata,msg.contentType)
                      del periksa["gift2"][lol]
                      try:
                            cl.sendMessage(lol,"Done")
                      except:
                            pass
                        
            
                      with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)
                        
               elif msg.to in periksa["gift"]:
                        target = msg.contentMetadata["mid"]
                        lol = msg.to
                        msg.contentType = 9
                        msg.contentMetadata = { 'STKPKGID':'3172',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'2'}
                        msg.to = target
                        msg.text == None
                        cl.sendMessage(msg.to,msg.text,msg.contentMetadata,msg.contentType)
                        del periksa["gift"][lol]
                        try:
                            cl.sendMessage(lol,"Done")
                        except:
                            pass
                        with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
               elif periksa["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendMessage(msg.to,"[displayName]:\n" + msg.contentMetadata["displayName"] + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
                    else:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendMessage(msg.to,"[displayName]:\n" + contact.displayName + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))

#=======================================================Youtube================================================================#

            elif "/ytb " in pesan:
                 query = pesan.replace("/ytb ","")
                 with requests.session() as s:
                     s.headers['user-agent'] = 'Mozilla/5.0'
                     url = 'http://www.youtube.com/results'
                     params = {'search_query': query}
                     r = s.get(url, params=params)
                     soup = BeautifulSoup(r.content, 'html5lib')
                     for a in soup.select('.yt-lockup-title > a[title]'):
                         if '&List' not in a['href']:
                               cl.sendMessage(msg.to,'http://www.youtube.com' + a['href'] + a['title'])

            elif pesan.startswith(respon['rname'] + " youtube "):
                query = pesan.replace(respon['rname'] + " youtube ","")
                cl.sendText(msg.to, "Searching...")
                with requests.session() as s:
                    s.headers['user-agent'] = 'Mozilla/5.0'
                    url = 'https://www.youtube.com/results'
                    params = {'search_query':query}
                    r = s.get(url, params=params)
                    soup = BeautifulSoup(r.content, 'html5lib')
                    loop = 1
                    for a in soup.select('.yt-lockup-title > a[title]'):
                        if '&list=' not in a['href']:
                            if loop == 0:
                                cl.sendMessage(msg.to, a['title']+'\nhttps://www.youtube.com'+a['href'])
                                break
                            else:
                                loop = loop - 1

#=======================================================RESPONSE================================================================#
                
            elif pesan.lower().startswith("responsetime"):
                cl.sendMessage(msg.to,str(time.time()-op.createdTime/1000.0))
            elif pesan.lower().startswith("responsename") or pesan == sname + ' responsename' or pesan.lower().startswith("rname"):
                cl.sendMessage(msg.to,rname)
            elif pesan.lower().startswith("sname"):
                cl.sendMessage(msg.to,sname)
            elif pesan.startswith(sname + " update rname "):
                xset = pesan.replace(sname + " update rname ","")
                respon['rname'] = xset
                with open('respon.json', 'w') as fp:
                    json.dump(respon, fp, sort_keys=True, indent=4)
                cl.sendMessage(msg.to,"Respons update to "+xset)
            elif pesan.startswith(rname + " update rname "):
                xset = pesan.replace(rname + " update rname ","")
                respon['rname'] = xset
                with open('respon.json', 'w') as fp:
                    json.dump(respon, fp, sort_keys=True, indent=4)
                cl.sendMessage(msg.to,"Respons update to "+xset)
            elif pesan.startswith(respon['rname'] + " update sname "):
                xset = pesan.replace(respon['rname'] + " update sname ","")
                respon['sname'] = xset
                with open('respon.json', 'w') as fp:
                    json.dump(respon, fp, sort_keys=True, indent=4)
                cl.sendMessage(msg.to,"Squad update to "+xset)
            elif pesan.startswith(respon['sname'] + " update sname "):
                xset = pesan.replace(respon['sname'] + " update sname ","")
                respon['sname'] = xset
                with open('respon.json', 'w') as fp:
                    json.dump(respon, fp, sort_keys=True, indent=4)
                cl.sendMessage(msg.to,"Squad update to "+xset)
#==============================================COMMAND===================================#
                
            elif pesan.startswith(respon['rname'] + " namelock:on") or pesan.startswith(respon['sname'] + " namelock:on") or pesan.lower().startswith('namelock:on'):
                if msg.to in periksa['gname']:
                    periksa['gname'][msg.to] = True
                    periksa['proname'][msg.to] = cl.getGroup(msg.to).name
                    cl.sendMessage(msg.to,"NameLock Enabled")
                else:
                    cl.sendMessage(msg.to,"NameLock Alredy On")
                    periksa['gname'][msg.to] = True
                    periksa['proname'][msg.to] = cl.getGroup(msg.to).name

            elif pesan.startswith(respon['rname'] + " namelock:off") or pesan.startswith(respon['sname'] + " namelock:off") or pesan.lower().startswith("Namelock:off"):
                if msg.to in periksa['gname']:
                    cl.sendMessage(msg.to,"NameLock Disable")
                    del periksa['gname'][msg.to]
                else:
                    del periksa['gname'][msg.to]
                    cl.sendMessage(msg.to,"NameLock Alredy Off")

#==============================================ICONLOCK===================================#
                    
            elif pesan.startswith(respon['rname'] + " iconlock:on") or pesan.startswith(respon['sname'] + " iconlock:on") or pesan.lower().startswith('iconlock:on'):
                if msg.to in periksa["picon"]:
                    cl.sendMessage(msg.to,"PictureProtect Already on")
                    periksa["picon"][msg.to] = True
                else:
                    periksa["picon"][msg.to] = True
                    cl.sendMessage(msg.to,"PictureProtect Enabled")
                    
            elif pesan.startswith(respon['rname'] + " iconlock:off") or pesan.startswith(respon['sname'] + " iconlock:off") or pesan.lower().startswith('iconlock:off'):
                if msg.to in periksa["picon"]:
                    cl.sendMessage(msg.to,"PictureProtect Already off")
                    del periksa["picon"][msg.to]
                else:
                    del periksa["picon"][msg.to]
                    cl.sendMessage(msg.to,"PictureProtect Dissabled")

#==============================================COMMAND===================================#

            elif pesan.startswith(respon['rname'] + " update welcome "):
                c = pesan.replace(respon['rname'] + " update welcome ","")
                if c in [""," ","\n",None]:
                    cl.sendMessage(msg.to,"The character string which can't be changed.")
                else:
                    periksa["welcomeM"] = c
                    cl.sendMessage(msg.to,"It is Welcome:\n\n" + c)
            elif pesan.startswith(respon['sname'] + " update welcome "):
                c = pesan.replace(respon['sname'] + " update welcome ","")
                if c in [""," ","\n",None]:
                    cl.sendMessage(msg.to,"The character string which can't be changed.")
                else:
                    periksa["welcomeM"] = c
                    cl.sendMessage(msg.to,"It is Welcome:\n\n" + c)

            elif pesan.startswith(respon['rname'] + " welcome:on") or pesan.startswith(respon['sname'] + 'welcome:on') or pesan.lower().startswith('welcomemessage:on'):
                if msg.to in periksa["welcomeN"]:
                    cl.sendMessage(msg.to,"Welcomemessage Already on")
                    periksa["welcomeN"][msg.to] = True
                else:
                    periksa["welcomeN"][msg.to] = True
                    cl.sendMessage(msg.to,"Welcomemessage Enabled")
                    
            elif pesan.startswith(respon['rname'] + " welcome:off") or pesan.startswith(respon['sname'] + 'welcome:off') or pesan.lower().startswith('welcomemessage:off'):
                if msg.to in periksa["welcomeN"]:
                    cl.sendMessage(msg.to,"Welcomemessage Already off")
                    del periksa["welcomeN"][msg.to]
                else:
                    del periksa["welcomeN"][msg.to]
                    cl.sendMessage(msg.to,"Welcomemessage Dissabled")
            
            elif pesan is None:
                pass
            if hHelp == pesan.lower() and helpMessage.lower() not in pesan.lower():
                    cl.sendMessage(msg.to,helpMessage)
            elif pesan.startswith(respon['rname'] + " update pic") or pesan.startswith(respon['sname'] + " update pic"):
                periksa['me'][msg.to] = True
                with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                cl.sendMessage(msg.to,"Send Pict")
            elif pesan.startswith(respon['rname'] + " update pvid") or pesan.startswith(respon['sname'] + " update pvid"):
                periksa['me'][msg.to] = True
                with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                cl.sendMessage(msg.to,"Send video")
            
            elif (rname + "type." in pesan) and helpMessage.lower() not in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("type.","")
                if xres == "":
                    pass
                else:
                    try:
                      number = int(xres)
                    except:
                      number = 1
                      cl.sendMessage(msg.to,"Must be a number")
                    if number > 0 and number < 7:
                      periksa['like'] = number
                      with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                      cl.sendMessage(msg.to,"Like type set to %s"%(str(number)))
                    else:
                      cl.sendMessage(msg.to,"Out of range")
                    
            elif "Change:" in pesan and helpMessage.lower() not in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("Change:","")
                if xres == "":
                    pass
                else:
                    anu = xres.split(':')
                    commandEdit = ['text','kick','kill','help','ats','all','bye','cancel','nuke','ourl','curl']
                    if anu[0] in commandEdit:
                      if anu[1] == "":
                        cl.sendMessage(msg.to,"error")
                      else:
                        if anu[0] == 'text':
                            anux = anu[1]
                            
                        anux = str(anu[1]).lower()
                        command[anu[0]] = anux
                        with open('command.json', 'w') as fp:
                          json.dump(command, fp, sort_keys=True, indent=4)
                        cl.sendMessage(msg.to,"success!\n %s set to %s"%(anu[0],anu[1]))
                    else:
                      cl.sendMessage(msg.to,"that command can't edit")
                      
            elif pesan.startswith(respon['rname'] + " comment ") and helpMessage.lower() not in pesan.lower():
                xres = pesan.replace(respon['rname'] + " comment ","")
                if xres == "":
                    pass
                else:
                    periksa['comment'] = xres
                    with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                    cl.sendMessage(msg.to,"Comment set to %s"%(xres))
            elif pesan.lower().startswith(respon['rname'] + " spam "):
                   xpesan = pesan.lower()
                   txt = xpesan.split(" ")
                   jmlh = int(txt[2])
                   teks = xpesan.replace(respon['rname'] + " spam "+str(txt[1])+" "+str(jmlh)+ " ","")
                   tulisan = jmlh * (teks+"\n")
                   if txt[1] == "on":
                        if jmlh <= 1000000:
                             for x in range(jmlh):
                                   cl.sendMessage(msg.to, teks)
                        else:
                               cl.sendMessage(msg.to, "ARE YOU FUCKING KIDDING ME? ")
                   elif txt[1] == "off":
                         if jmlh <= 1000000:
                               cl.sendMessage(msg.to, tulisan)
                         else:
                               cl.sendMessage(msg.to, "ARE YOU FUCKING KIDDING ME? ")
            elif pesan.startswith(respon['rname'] + " add;") and helpMessage.lower() not in pesan.lower():
                xres = pesan.replace(respon['rname'] + " add;","")
                if xres not in helpMessage:
                  yres = xres.replace(xres[:1]+";","")
                  abjadlist = yres.split(' ')
                  periksa['emo'][xres[:1]] = abjadlist
                  with open('settingan.json', 'w') as fp:
                     json.dump(periksa, fp, sort_keys=True, indent=4)
                  cl.sendMessage(msg.to,"emoji %s added to list"%(yres))
            elif pesan.startswith(respon['rname'] + " con ") and helpMessage.lower() not in pesan.lower():
                emox = pesan.replace(respon['rname'] + " con ","")
                if emox not in helpMessage:
                  jmlh = len(emox)
                  msk = int(0)
                  mskx = int(0)
                  listx = []
                  lol = ""
                  for x in range(jmlh):
                     listx.append(emox[msk])
                     msk += 1
                  for x in listx:
                     mskx += 1
                     if x in periksa['emo']:
                        lol += random.choice(periksa['emo'][x])
                     else:
                        lol =+ ' '
                  cl.sendMessage(msg.to,"%s"%(lol))
            elif pesan.startswith(respon['rname'] + " music ") and helpMessage.lower() not in pesan.lower():
                songname = pesan.replace(respon['rname'] + " music ","")
                params = {'songname':songname}
                r=requests.get('https://ide.fdlrcn.com/workspace/yumi-apis/joox?'+urllib.parse.urlencode(params))
                data = r.text
                data=json.loads(data)
                
                for song in data:
                    cl.sendMessage(msg.to,"Music\n\n%s (%s)\nDownload Link: %s"%(song[0],song[1],song[4]))
                    cl.sendMessage(msg.to,"Downloading....")
                    cl.sendAudioWithURL(msg.to,song[4])
            elif pesan.startswith(respon['rname'] + " lyric "):
                songname = pesan.replace(respon['rname'] + " lyric ","")
                params = {'songname':songname}
                r=requests.get('https://ide.fdlrcn.com/workspace/yumi-apis/joox?'+urllib.parse.urlencode(params))
                data = r.text
                data=json.loads(data)
                for song in data:
                    cl.sendMessage(msg.to,"%s \n\n %s"%(song[0],song[5]))
                    
            elif pesan.startswith(respon['rname'] + " autojoin:"):
                xres = pesan.replace(respon['rname'] + " autojoin:","")
                if xres == "off":
                    periksa['autojoin'] = "off"
                    cl.sendMessage(msg.to,"Auto join OFF")
                elif xres == "on":
                    periksa['autojoin'] = "all"
                    cl.sendMessage(msg.to,"Auto join Everyone")
                elif xres == "wl":
                    periksa['autojoin'] = "wl"
                    cl.sendMessage(msg.to,"Auto join Whitelist Only")
            elif pesan.startswith(respon['rname'] + " autolike:"):
                xres = pesan.replace(respon['rname'] + " autolike:","")
                if xres == "off":
                    periksa['autolike'] = False
                    cl.sendMessage(msg.to,"Auto Like OFF")
                elif xres == "on":
                    periksa['autolike'] = True
                    cl.sendMessage(msg.to,"Auto Like ON")
            elif pesan.startswith(respon['rname'] + " autoadd:"):
                xres = pesan.replace(respon['rname'] + " autoadd:","")
                if xres == "off":
                    periksa['autoadd'] = False
                    cl.sendMessage(msg.to,"Auto Add Friend OFF")
                elif xres == "on":
                    periksa['autoadd'] = True
                    cl.sendMessage(msg.to,"Auto Add Friend ON")
            elif pesan.startswith(respon['rname'] + " allowban:"):
                xres = pesan.replace(respon['rname'] + " allowban:","")
                if xres == "off":
                    del periksa['autopurge'][msg.to]
                    cl.sendMessage(msg.to,"Allow banned user OFF")
                elif xres == "on":
                    periksa['autopurge'][msg.to] = True
                    cl.sendMessage(msg.to,"Allow banned user ON")
            elif pesan.startswith(respon['rname'] + " mc:"):
                xres = pesan.replace(respon['rname'] + " mc:","")
                if xres == "off":
                    periksa['mimic'] = False
                    cl.sendMessage(msg.to,"Have fun is gone")
                elif xres == "on":
                    periksa['mimic'] = True
                    cl.sendMessage(msg.to,"Have fun is started")
#==============================================LINKPROTECT===================================#
            elif pesan.startswith(respon['rname'] + " qr:"):
                xres = pesan.replace(respon['rname'] + " qr:","")
                if xres == "off":
                    del periksa['lockqr'][msg.to]
                    cl.sendMessage(msg.to,"Qr not longer to protect")
                elif xres == "on":
                    periksa['lockqr'][msg.to] = True
                    cl.sendMessage(msg.to,"Qr hasbeen protected")

#==============================================CANCELALL===================================#
            elif pesan.startswith(respon['rname'] + " cancelall:"):
                xres = pesan.replace(respon['rname'] + " cancelall:","")
                if xres == "off":
                    del periksa['autocancel'][msg.to]
                    cl.sendMessage(msg.to,"Normal invite allowed")
                elif xres == "on":
                    periksa['autocancel'][msg.to] = True
                    cl.sendMessage(msg.to,"Refuse invite has been acktive")

#==============================================PROTECTION===================================#
            elif pesan.startswith(respon['rname'] + " protection:"):
                xres = pesan.replace(respon['rname'] + " protection:","")
                if xres == "off":
                    del periksa['protect'][msg.to]
                    cl.sendMessage(msg.to,"Protection off")
                elif xres == "on":
                    periksa['protect'][msg.to] = True
                    cl.sendMessage(msg.to,"Protection is on")

#==============================================PJOIN===================================#
            elif pesan.startswith(respon['rname'] + " pjoin:"):
                xres = pesan.replace(respon['rname'] + " pjoin:","")
                if xres == "off":
                    del periksa['pjoin'][msg.to]
                    cl.sendMessage(msg.to,"Protect join is off")
                elif xres == "on":
                    periksa['pjoin'][msg.to] = True
                    cl.sendMessage(msg.to,"Protect join is on")

#==============================================PROTECTMAX===================================#
            elif pesan.startswith(respon['rname'] + " protectmax:"):
                xres = pesan.replace(respon['rname'] + " protectmax:","")
                if xres == "off":
                    del periksa['protect'][msg.to]
                    del periksa['lockqr'][msg.to]
                    del periksa['autopurge'][msg.to]
                    del periksa['autocancel'][msg.to]
                    del periksa["picon"][msg.to]
                    del periksa["gname"][msg.to]
                    del periksa["pjoin"][msg.to]
                    cl.sendMessage(msg.to,"All Protect OFF")
                elif xres == "on":
                    periksa["picon"][msg.to] = True
                    periksa["gname"][msg.to] = True
                    periksa["proname"][msg.to] = cl.getGroup(msg.to).name
                    periksa['protect'][msg.to] = True
                    periksa['autocancel'][msg.to] = True
                    periksa['lockqr'][msg.to] = True
                    periksa['autopurge'][msg.to] = True
                    periksa['pjoin'][msg.to] = True
                    cl.sendMessage(msg.to,"All Protect ON")
#==============================================SETTING===================================#
#==============================================SETTING===================================#
            elif pesan.startswith(respon['rname'] + " setting") or pesan.startswith(respon['sname'] + " setting"):
                if msg.to in periksa['protect']:
                    protect = "On"
                else:
                    protect = "Off"
                if msg.to in periksa['autopurge']:
                    autopurge = "On"
                else:
                    autopurge = "Off"
                if msg.to in periksa['lockqr']:
                    lockqr = "On"
                else:
                    lockqr = "Off"
                if msg.to in periksa['autocancel']:
                    autocancel = "On"
                else:
                    autocancel = "Off"
                if periksa['autolike'] == True:
                    autolike = "On"
                else:
                     autolike = "Off"
                if periksa['autoadd'] == True:
                    autoadd = "On"
                else:
                     autoadd = "Off"
                if periksa['autorejc'] == True:
                    autorejc = "On"
                else:
                     autorejc = "Off"
                if periksa['autojoin'] == "all":
                    autojoin = "All"
                elif periksa['autojoin'] == "wl":
                     autojoin = "Wl"
                else:
                    autojoin = "Off"
                koment = periksa['comment']
                if msg.to in periksa['gname']:
                    proname = '%s' % cl.getGroup(msg.to).name
                else:
                    proname = 'Off'
                if msg.to in periksa['picon']:
                    icon = 'On\n'
                else:
                    icon = 'Off\n'
                if msg.to in periksa['welcomeN']:
                    welcome = str(periksa["welcomeM"])
                else:
                    welcome = 'Off'
                if periksa['pjoin']:
                    pjoin = "On"
                else:
                    pjoin = "Off"
#                liketype = periksa['like']
                cl.sendMessage(msg.to,"  ⊰❉⊱SETTING⊰❉⊱  \n❉⊱Respons: %s\n❉⊱Sname: %s\n\n   ⊰❉⊱Status In Groups⊰❉⊱ \n❉⊱Protect: %s\n❉⊱Autocancel: %s\n❉⊱Allowban: %s\n❉⊱Lock QR: %s\n❉⊱protect join: %s\n❉⊱Namelock: %s\n❉⊱PictureLock: %s\n   ⊰❉⊱For Self⊰❉⊱ \n❉⊱Autolike: %s\n❉⊱Autoadd: %s\n❉⊱Autoreject: %s\n❉⊱Autojoin: %s\n❉⊱Comments: %s\n❉⊱Welcomemessage: %s\n"%(respon['rname'],respon['sname'],protect,autocancel,autopurge,lockqr,pjoin,proname,icon,autolike,autoadd,autorejc,autojoin,koment,welcome))
            elif pesan.startswith(respon['rname'] + " mc add @") or pesan.startswith(respon['sname'] + " mc add @"):
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    G = cl.getGroupIdsJoined()
                    cgroup = cl.getGroups(G)
                    ngroup = ""
                    for mention in mentionees:
                        periksa['tmimic'][mention['M']] = True
                        cl.sendMessage(msg.to,"Target Mimic has been Added")
                        with open('settingan.json', 'w') as fp:
                            json.dump(periksa, fp, sort_keys=True, indent=4)
            elif pesan.startswith(respon['rname'] + " mc del @") or pesan.startswith(respon['sname'] + " mc del @"):
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    G = cl.getGroupIdsJoined()
                    cgroup = cl.getGroups(G)
                    ngroup = ""
                    for mention in mentionees:
                        del periksa['tmimic'][mention['M']]
                        cl.sendMessage(msg.to,"Target Mimic has been Removed")
                        with open('settingan.json', 'w') as fp:
                            json.dump(periksa, fp, sort_keys=True, indent=4)
            elif  pesan.startswith(respon['rname'] + " reject:"):
                xres = pesan.replace(respon['rname'] + " reject:","")
                if xres == "off":
                    periksa['autorejc'] = False
                    cl.sendMessage(msg.to,"Rejection invite is off")
                elif xres == "on":
                    periksa['autorejc'] = True
                    cl.sendMessage(msg.to,"Rejection invite is on")
            elif pesan.startswith(respon['rname'] + " refuse all") or pesan.startswith(respon['sname'] + " refuse all"):
                cl.sendMessage(msg.to,"Please wait....")
                g1 = cl.getGroupIdsInvited()
                for x in g1:
                    cl.rejectGroupInvitation(x)
                pass
                cl.sendMessage(msg.to,"All Invite Has Been Refuse")
            elif pesan.startswith(respon['rname'] + " set:on") or pesan.startswith(respon['sname'] + " set:on"):
                if msg.to in sider['readPoint']:
                    try:
                        del sider['readPoint'][msg.to]
                        del sider['readMember'][msg.to]
                        del sider['setTime'][msg.to]
                    except:
                        pass
                    sider['readPoint'][msg.to] = msg.id
                    sider['readMember'][msg.to] = ""
                    sider['setTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                    sider['ROM'][msg.to] = {}
                    with open('sider.json', 'w') as fp:
                      json.dump(sider, fp, sort_keys=True, indent=4)
                    cl.sendMessage(msg.to,"Set already on Lurkers")
                else:
                    try:
                        del sider['readPoint'][msg.to]
                        del sider['readMember'][msg.to]
                        del sider['setTime'][msg.to]
                    except:
                        pass
                    sider['readPoint'][msg.to] = msg.id
                    sider['readMember'][msg.to] = ""
                    sider['setTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                    sider['ROM'][msg.to] = {}
                    with open('sider.json', 'w') as fp:
                       json.dump(sider, fp, sort_keys=True, indent=4)
                    cl.sendMessage(msg.to,"Set On Lurkers")
                    #print sider
            elif pesan.startswith(respon['rname'] + " set:off") or pesan.startswith(respon['sname'] + " set:off"):
                if msg.to not in sider['readPoint']:
                    cl.sendMessage(msg.to,"Set already Off Lurkers")
                else:
                    try:
                       del sider['readPoint'][msg.to]
                       del sider['readMember'][msg.to]
                       del sider['setTime'][msg.to]
                    except:
                       pass
                    cl.sendMessage(msg.to,"Set already Off Lurkers")				
            elif pesan.startswith(respon['rname'] + " lurkers2") or pesan.startswith(respon['sname'] + " lurkers2"):
                print ("Lurkers2........")
                if msg.to in sider['readPoint']:
                    if sider["ROM"][msg.to].items() == []:
                        cl.sendMessage(msg.to, "Lurkers:\nNone")
                    else:
                        chiya = []
                        for rom in sider["ROM"][msg.to].items():
                            chiya.append(rom[1])

                        cmem = cl.getContacts(chiya)
                        zx = ""
                        zxc = ""
                        zx2 = []
                        xpesan = '***Ciee Cctv***\n\n'
                        for x in range(len(cmem)):
                            xname = str(cmem[x].displayName)
                            pesan = ''
                            pesan2 = pesan+"@a\n"
                            xlen = str(len(zxc)+len(xpesan))
                            xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                            zx = {'S':xlen, 'E':xlen2, 'M':cmem[x].mid}
                            zx2.append(zx)
                            zxc += pesan2
                        msg.contentType = 0

                        print (zxc)
                        msg.text = xpesan+ zxc + "\nSet: %s\nView: %s"%(sider['setTime'][msg.to],datetime.now().strftime('%H:%M:%S'))
                        lol ={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                        print (lol)
                        msg.contentMetadata = lol
                        try:
                            cl.sendMessage(msg)
                        except Exception as error:
                            print (error)
                    try:
                        del sider['readPoint'][msg.to]
                        del sider['readMember'][msg.to]
                    except:
                        pass
                    sider['readPoint'][msg.to] = msg.id
                    sider['readMember'][msg.to] = ""
                    sider['setTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                    sider['ROM'][msg.to] = {}
                else:
                    cl.sendMessage(msg.to, "Set Lurkes first")
            elif pesan.startswith(respon['rname'] + " lurkers") or pesan.startswith(respon['sname'] + " lurkers"):
                print ("Getting Read and Unread Data...")
                if msg.to in sider['readPoint']:
                    cl.sendMessage(msg.to, "╔════════════════\n║READCHAT IN GROUP\n╠════════════════%s\n║\n╚════════════════" % (sider['readMember'][msg.to]))
                    try:
                        del sider['readPoint'][msg.to]
                        del sider['readMember'][msg.to]
                    except:
                        pass
                    sider['readPoint'][msg.to] = msg.id
                    sider['readMember'][msg.to] = ""
                    sider['ROM'][msg.to] = {}
                    cl.sendMessage(msg.to, "lurking started")
                else:
                    try:
                        del sider['readPoint'][msg.to]
                        del sider['readMember'][msg.to]
                    except:
                        pass
                    sider['readPoint'][msg.to] = msg.id
                    sider['readMember'][msg.to] = ""
                    sider['ROM'][msg.to] = {}
                    cl.sendMessage(msg.to, "lurking started")					
            elif pesan.startswith(respon['rname'] + " groups") or pesan.startswith(respon['sname'] + " groups"):
                    gid = cl.getGroupIdsJoined()
                    num = 0
                    g = ""
                    for i in gid:
                       g += "%i - " % num + "%s" % (cl.getGroup(i).name + "(%s)\n" % (str (len (cl.getGroup(i).members))))
                       num = (num+1)
                    cl.sendMessage(msg.to,"Group List:\n\n"+ g + "Total Groups : " + str(len(gid)))
            elif pesan.startswith(respon['rname'] + " look "):
                   umid = pesan.replace(respon['rname'] + " look ",'')
                   msg.contentType = 13
                   msg.text = None
                   msg.contentMetadata = {'mid': umid}
                   cl.sendMessage(msg)
            elif pesan.startswith(respon['rname'] + " search @") or pesan.startswith(respon['sname'] + " search @"):
                   if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    G = cl.getGroupIdsJoined()
                    cgroup = cl.getGroups(G)
                    ngroup = ""
                    for mention in mentionees:
                      for x in range(len(cgroup)):
                        gMembMids = [contact.mid for contact in cgroup[x].members]
                        if mention['M'] in gMembMids:
                            ngroup += "\n" + cgroup[x].name + " | Members: " + str(len(cgroup[x].members))    
                    if ngroup == "":
                          cl.sendMessage(msg.to, "Tidak ditemukan")
                    else:
                        cl.sendMessage(msg.to,"Ada di Group:\n%s\n"%(ngroup))
            elif pesan.startswith(respon['rname'] + " ourl") or pesan.startswith(respon['sname'] + " ourl"):
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventedJoinByTicket = False
                    cl.updateGroup(X)
                    gurl = cl.reissueGroupTicket(msg.to)
                    cl.sendMessage(msg.to,"Link Group = http://line.me/R/ti/g/"+gurl)
                else:
                    pass
                    
            elif pesan.startswith(respon['rname'] + " curl") or pesan.startswith(respon['sname'] + " curl"):
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventedJoinByTicket = True
                    cl.updateGroup(X)
                    cl.sendMessage(msg.to,"Done close qr")
                else:
                    pass
            elif pesan.startswith(respon['rname'] + " gid") or pesan.startswith(respon['sname'] + " gid"):
                cl.sendMessage(msg.to,msg.to)
            elif ".blank" in pesan:
                   msg.contentType = 13
                   msg.text = None
                   msg.contentMetadata = {'mid': "6969697969796969696696969'"}
                   cl.sendMessage(msg)
                   cl.sendMessage(msg.to, "√")
            elif pesan.startswith(respon['rname'] + " myid") or pesan.startswith(respon['sname'] + " myid"):
                cl.sendMessage(msg.to,msg._from)
            elif pesan.lower() in ["sp",'speed']:
                start = time.time()
                cl.sendMessage(msg.to, "Loading.....")
                elapsed_time = time.time() - start
                cl.sendMessage(msg.to, "%s Sec" % (elapsed_time))

            elif pesan.startswith(respon['sname'] + " speed"):
                start = time.time()
                cl.sendMessage(msg.to, "Loading.....")
                elapsed_time = time.time() - start
                cl.sendMessage(msg.to, "%s Sec" % (elapsed_time))
            #elif hBye == pesan.lower() and helpMessage.lower() not in pesan.lower():
            #    wb.leaveGroup(msg.to)
            #    kk.leaveGroup(msg.to)
            #    wb1.leaveGroup(msg.to)
            #    wb2.leaveGroup(msg.to)
            #    wb3.leaveGroup(msg.to)
            elif pesan.startswith(respon['rname'] + " staff:on") or pesan.startswith(respon['sname'] + " staff:on"):
                periksa["addwl"][msg.to] = True
                cl.sendMessage(msg.to,"Send contact for add to stafflist")
            elif pesan.startswith(respon['rname'] + " staff:off") or pesan.startswith(respon['sname'] + " staff:off"):
                del periksa["addwl"][msg.to]
                cl.sendMessage(msg.to,"Stop")
            elif pesan.startswith(respon['rname'] + " unstaff:on") or pesan.startswith(respon['sname'] + " unstaff:on"):
                periksa["delwl"][msg.to] = True
                cl.sendMessage(msg.to,"Send contact for deleted stafflist")
            elif pesan.startswith(respon['rname'] + " unstaff:off") or pesan.startswith(respon['sname'] + " unstaff:off"):
                del periksa["delwl"][msg.to]
                cl.sendMessage(msg.to,"Stop")
            elif pesan.startswith(respon['rname'] + " tagmem") or pesan.startswith(respon['sname'] + " tagmem"):
                group = cl.getGroup(msg.to)
                nama = [contact.mid for contact in group.members]
                nama.remove(mid)
                nm1, nm2, nm3, nm4,  nm5, jml = [], [], [], [],  [], len(nama)
                if jml <= 150:
                    Tagall1(msg.to, nama)
                if jml > 150 and jml < 500:
                    for i in range(0, 150):
                        nm1 += [nama[i]]
                    Tagall1(msg.to, nm1)
                    for j in range(149, len(nama)-1):
                        nm2 += [nama[j]]
                    Tagall1(msg.to, nm2)
                    for k in range(298, len(nama)-2):
                          nm3 += [nama[k]]
                    Tagall1(msg.to, nm3)
                    for l in range(447, len(nama)-3):
                          nm4 += [nama[l]]
                    Tagall1(msg.to, nm4)
                    for m in range(500, len(nama)-4):
                          nm5 += [nama[m]]
                    Tagall1(msg.to, nm5)
            elif pesan.startswith(respon['sname'] + " join "):
                 xlink = pesan.replace(respon['sname'] + " join ","")
                 ticket = xlink.split("/ti/g/")
                 try:
                   group = cl.findGroupByTicket(ticket[1])
                   cl.acceptGroupInvitationByTicket(group.id,ticket[1])
                   cl.sendMessage(msg.to,"Joined to %s"%(group.name))
                 except Exception as error:
                   cl.sendMessage(msg.to,"Failed\n %s"%(error))
            elif pesan.startswith(respon['rname'] + " gift:on") or pesan.startswith(respon['sname'] + " gift:on"):
                periksa["gift"][msg.to] = True
                cl.sendMessage(msg.to,"Send contact")
            elif pesan.startswith(respon['rname'] + " gift:on:"):
                xres = pesan.replace(respon['rname'] + " gift:on:","")
                jumlah = int(xres)
                if jumlah >= 9999:
                    cl.sendMessage(msg.to,"Out of Range")
                else:
                  periksa["gift2jumlah"] = jumlah
                  periksa["gift2"][msg.to] = True
                  cl.sendMessage(msg.to,"Send Contact")
            elif pesan.startswith(respon['rname'] + " ban:repeat") or pesan.startswith(respon['sname'] + " ban:repeat"):
                periksa["addbanmode"][msg.to] = True
                cl.sendMessage(msg.to,"Send a Contact")
            elif pesan.startswith(respon['rname'] + " target:repeat") or pesan.startswith(respon['sname'] + " target:repeat"):
                periksa["addtarget"][msg.to] = True
                cl.sendMessage(msg.to,"Send a Contact")
            elif pesan.startswith(respon['rname'] + " deltarget:repeat") or pesan.startswith(respon['sname'] + " deltarget:repeat"):
                periksa["deltarget"][msg.to] = True
                cl.sendMessage(msg.to,"Send a Contact")
            elif pesan.startswith(respon['rname'] + " unban:repeat") or pesan.startswith(respon['sname'] + " unban:repeat"):
                periksa["delbanmode"][msg.to] = True
                cl.sendMessage(msg.to,"Send a Contact")
            elif pesan.startswith(respon['rname'] + " repeat:off") or pesan.startswith(respon['sname'] + " repeat:off"):
                if msg.to in periksa["addmode"]:
                    del periksa["addbanmode"][msg.to]
                    cl.sendMessage(msg.to,"Repeat turn off")
                elif msg.to in periksa["addtarget"]:
                    del periksa["addtarget"][msg.to]
                    cl.sendMessage(msg.to,"Repeat turn off")
                elif msg.to in periksa["deltarget"]:
                    del periksa["deltarget"][msg.to]
                    cl.sendMessage(msg.to,"Repeat turn off")
                elif msg.to in periksa["delbanmode"]:
                    del periksa["delbanmode"][msg.to]
                    cl.sendMessage(msg.to,"Repeat turn off")
                else:
                    cl.sendMessage(msg.to,"Repeat Already off")
            elif pesan.startswith(respon['rname'] + " addstaff @") or pesan.startswith(respon['sname'] + " addstaff @"):
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["wl"]:
                            cl.sendMessage(msg.to,"already")
                        else:
                            periksa["wl"][mention['M']] = True
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendMessage(msg.to,"Success!")
            elif pesan.startswith(respon['rname'] + " delstaff @") or pesan.startswith(respon['sname'] + " delstaff @"):
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["wl"]:
                            del periksa["wl"][mention['M']]
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendMessage(msg.to,"Deleted")
                        else:
                            cl.sendMessage(msg.to,"Not in whitelist")
            elif pesan.startswith(respon['rname'] + " addban @") or pesan.startswith(respon['sname'] + " addban @"):
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["banlist"]:
                            cl.sendMessage(msg.to,"Already banlist")
                        elif mention['M'] in Bots or mention['M'] in periksa["wl"]:
                            cl.sendMessage(msg.to,"Can't ban owner/admin/bot/stafflist")
                        else:
                            periksa["banlist"][mention['M']] = True
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendMessage(msg.to,"Success!")
            elif pesan.startswith(respon['rname'] + " delban @") or pesan.startswith(respon['sname'] + " delban @"):
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["banlist"]:
                            del periksa["banlist"][mention['M']]
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendMessage(msg.to,"Success!")
                        else:
                            cl.sendMessage(msg.to,"Not in banlist")
            elif pesan.startswith(respon['rname'] + " addtarget @") or pesan.startswith(respon['sname'] + " addtarget @"):
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["target"]:
                            cl.sendMessage(msg.to,"Sudah dalam banlist")
                        elif mention['M'] in Bots or mention['M'] in periksa["wl"]:
                            cl.sendMessage(msg.to,"Can't add owner/admin/bot/whitelist to target")
                        else:
                            periksa["target"][mention['M']] = True
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendMessage(msg.to,"Success!")
            elif pesan.startswith(respon['rname'] + " deltarget @") or pesan.startswith(respon['sname'] + " deltarget @"):
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["target"]:
                            del periksa["target"][mention['M']]
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendMessage(msg.to,"Success!")
                        else:
                            cl.sendMessage(msg.to,"Not in target list")
            elif pesan.startswith(respon['rname'] + " targetlist") or pesan.startswith(respon['sname'] + " targetlist"):
                if periksa["target"] == {}:
                    cl.sendMessage(msg.to,"None")
                else:
                    mc = []
                    for mi_d in periksa["target"]:
                        mc.append(mi_d)
                    pass
                    cban = cl.getContacts(mc)
                    nban = []
                    for x in range(len(cban)):
                        nban.append(cban[x].displayName)
                    pass
                    jo = "\n❉⊱ ".join(str(i) for i in nban)
                    cl.sendMessage(msg.to,"⊰❉⊱ Target List ⊰❉⊱\n\n❉⊱ %s\n\nTotal Banlist: %s"%(jo,str(len(cban))))
            elif pesan.startswith(respon['rname'] + " banlist") or pesan.startswith(respon['sname'] + " banlist"):
                if periksa["banlist"] == {}:
                    cl.sendMessage(msg.to,"None")
                else:
                    mc = []
                    for mi_d in periksa["banlist"]:
                        mc.append(mi_d)
                    pass
                    cban = cl.getContacts(mc)
                    nban = []
                    for x in range(len(cban)):
                        nban.append(cban[x].displayName)
                    pass
                    jo = "\n ".join(str(i) for i in nban)
                    cl.sendMessage(msg.to,"⊰❉⊱ List Banned ⊰❉⊱\n\n❉⊱ %s\n\nTotal Banlist: %s"%(jo,str(len(cban))))
            elif pesan.startswith(respon['rname'] + " check ban") or pesan.startswith(respon['sname'] + " check ban"):
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in periksa["banlist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    cocoa = []
                    for mm in matched_list:
                        cocoa.append(mm)
                    pass
                    cban = cl.getContacts(cocoa)
                    nban = []
                    for x in range(len(cban)):
                        nban.append(cban[x].displayName)
                    pass
                    jo = "\n❉⊱ ".join(str(i) for i in nban)
                    if cocoa != []:
                        cl.sendMessage(msg.to,"⊰❉⊱ Ban in this Group ⊰❉⊱ \n❉⊱ %s\n\nTotal Banlist: %s"%(jo,str(len(cban))))
                    else:
                        cl.sendMessage(msg.to,"None")
            elif pesan.startswith(respon['rname'] + " ban user") and helpMessage.lower() not in pesan.lower():
                if periksa["banlist"] == {}:
                    cl.sendMessage(msg.to,"Nothing")
                else:
                    cl.sendMessage(msg.to,"Show banlist with contact:")
                    h = ""
                    for i in periksa["banlist"]:
                        h = cl.getContact(i)
                        M = Message()
                        M.to = msg.to
                     #   msg.contentType = 13
                        M.contentMetadata = {'mid': i}
                        cl.sendMessage(msg.to,'',M.contentMetadata,13)
            elif pesan.startswith(respon['rname'] + " stafflist") and helpMessage.lower() not in pesan.lower():
                if periksa["wl"] == {}:
                    cl.sendMessage(msg.to,"None")
                else:
                    mc = []
                    for mi_d in periksa["wl"]:
                        mc.append(mi_d)
                    pass
                    cban = cl.getContacts(mc)
                    nban = []
                    for x in range(len(cban)):
                        nban.append(cban[x].displayName)
                    pass
                    jo = "\n❉⊱ ".join(str(i) for i in nban)
                    cl.sendMessage(msg.to," Staff List \n\n %s\n\nStafflist: %s"%(jo,str(len(cban))))
            elif pesan.startswith(respon['rname'] + " staff user") and helpMessage.lower() not in pesan.lower():
                if periksa["wl"] == {}:
                    cl.sendMessage(msg.to,"Nothing")
                else:
                    cl.sendMessage(msg.to,"Show Stafflist with contact:")
                    h = ""
                    for i in periksa["wl"]:
                        h = cl.getContact(i)
                        M = Message()
                        M.to = msg.to
                      #  msg.contentType = 13
                        M.contentMetadata = {'mid': i}
                        cl.sendMessage(msg.to,'',msg.contentMetadata,13)
            elif pesan.startswith(respon['rname'] + " mc target") and helpMessage.lower() not in pesan.lower():
                if periksa["tmimic"] == {}:
                    cl.sendMessage(msg.to,"None")
                else:
                    mc = []
                    for mi_d in periksa["tmimic"]:
                        mc.append(mi_d)
                    pass
                    cban = cl.getContacts(mc)
                    nban = []
                    for x in range(len(cban)):
                        nban.append(cban[x].displayName)
                    pass
                    jo = "\n• ".join(str(i) for i in nban)
                    cl.sendMessage(msg.to," Mimic Target List: \n\n %s\n\nTotal: %s"%(jo,str(len(cban))))		
            elif pesan.lower().startswith("wban "):
                wban = pesan.lower().replace("wban","").lstrip().rstrip()
                wbanlist.append(wban)
                cl.sendMessage(msg.to,"%s is now blacklisted."%wban)
            elif pesan.lower().startswith("wunban "):
                wunban = pesan.lower().replace("wunban","").lstrip().rstrip()
                if wunban in wbanlist:
                    wbanlist.remove(wunban)
                    cl.sendMessage(msg.to,"%s is no longer blacklisted."%wunban)
                else:
                    cl.sendMessage(msg.to,"%s is not blacklisted."%wunban)
            elif pesan.startswith(respon['rname'] + " wbanlist"):
                tst = "Word banlist:\n"
                if len(wbanlist) > 0:
                    for word in wbanlist:
                        tst += "- %s"%word
                    cl.sendMessage(msg.to,tst)
                else:
                    cl.sendMessage(msg.to,"Wbanlist is empty!")
            elif pesan.startswith(respon['rname'] + " contact"):
                if msg.contentMetadata is not None:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        msg.contentMetadata = {'mid': target}
                        cl.sendMessage(msg.to,'',msg.contentMetadata,13)
                else:
                    pass
            elif "me" == pesan.lower() and helpMessage.lower() not in pesan.lower():
                      '''msg.contentType = 13
                      msg.text = None'''
                      msg.contentMetadata = {'mid': msg._from}
                      cl.sendMessage(msg.to,'',msg.contentMetadata,13)
            elif pesan.startswith(respon['rname'] + " cancel"):
                    group = cl.getGroup(msg.to)
                    if group.invitee is None:
                        cl.sendMessage(op.message.to, "No invites")
                    else:
                        gInviMids = [contact.mid for contact in group.invitee]
                        cl.cancelGroupInvitation(msg.to, gInviMids)
                        cl.sendMessage(msg.to, "Success cancel " + str(len(group.invitee)) + " invites" )
            elif pesan.startswith(respon['rname'] + " void") and helpMessage.lower() not in pesan.lower():
                if msg.toType == 2:
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if g.mid not in Bots:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendMessage(msg.to,"Target not found")
                    else:
                        for target in targets:
                            try:
                                kicker=random.choice(KAC)
                                kicker.inviteIntoGroup(msg.to, [target])
                                kicker.cancelGroupInvitation(msg.to, [target])
                            except:
                              try:
                                kicker=random.choice(KAC)
                                kicker.inviteIntoGroup(msg.to, [target])
                                kicker.cancelGroupInvitation(msg.to, [target])
                              except:
                               	kicker=random.choice(KAC)
                                kicker.inviteIntoGroup(msg.to, [target])
                                kicker.cancelGroupInvitation(msg.to, [target])
            elif pesan.startswith(respon['rname'] + " talkban") and helpMessage.lower() not in pesan.lower():
                if msg.contentMetadata is not None:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            if target in open('tbanlist.txt').read():
                                cl.sendMessage(msg.to, "Already tbanned")
                            else:
                                tbanadd = open('tbanlist.txt', 'a')
                                tbanadd.write(target + "\n")
                                tbanadd.close()
                                cl.sendMessage(msg.to, "Added to tban list")
                        except:
                            cl.sendMessage(msg.to, "Could not tban")
            elif pesan.startswith(respon['rname'] + " contact:") and helpMessage.lower() not in pesan.lower():
                xres = pesan.replace(respon['rname'] + " contact:","")
                if xres == "off":
                    periksa['contact'] = False
                    cl.sendMessage(msg.to,"Contact info Disabled")
                elif xres == "on":
                    periksa['contact'] = True
                    cl.sendMessage(msg.to,"Contact info Enabled")
            elif 'ginfo' == pesan.lower() and helpMessage.lower() not in pesan.lower():
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        gCreator = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                   # if periksa["lang"] == "JP":
                        if ginfo.invitee is None:
                            sinvitee = "0"
                        else:
                            sinvitee = str(len(ginfo.invitee))
                        if ginfo.preventedJoinByTicket == True:
                            u = "close"
                        else:
                            u = "open"
                        cl.sendMessage(msg.to,"[group name]\n" + str(ginfo.name) + "\n[gid]\n" + msg.to + "\n[group creator]\n" + gCreator + "\n[profile status]\nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus + "\nmembers:" + str(len(ginfo.members)) + "members\npending:" + sinvitee + "people\nURL:" + u + "it is inside")
                    else:
                        cl.sendMessage(msg.to,"[group name]\n" + str(ginfo.name) + "\n[gid]\n" + msg.to + "\n[group creator]\n" + gCreator + "\n[profile status]\nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus)
                else:
                    if periksa["lang"] == "JP":
                        cl.sendMessage(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendMessage(msg.to,"Not for use less than group")
            elif pesan.startswith(respon['rname'] + " tunban") and helpMessage.lower() not in pesan.lower():
                if msg.contentMetadata is not None:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            if target not in open('tbanlist.txt').read():
                                cl.sendMessage(msg.to, "Not tbanned")
                            elif target in open('tbanlist.txt').read():
                                try:
                                    with open('tbanlist.txt', 'r') as blexpfile:
                                        blexp = blexpfile.read().replace(target+ "\n", '')
                                except OSError as exception:
                                    print (exception)
                                else:
                                    with open('tbanlist.txt', 'w') as blexprec:
                                        blexprec.write(blexp)
                                cl.sendMessage(msg.to, "Removed from tban list")
                        except:
                            cl.sendMessage(msg.to, "Could not tunban")
            
                                
            elif hNuke == pesan.lower() and helpMessage.lower() not in pesan.lower():
                if msg.toType == 2:
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if g.mid not in Bots:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendMessage(msg.to,"Target not found")
                    else:
                        for target in targets:
                            try:
                                klist=[cl]
                                kicker=random.choice(klist)
                                kicker.kickoutFromGroup(msg.to,[target])
                            except:
                                pass
            elif pesan.startswith(respon['rname'] + " purge") and helpMessage.lower() not in pesan.lower():
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in periksa["banlist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        cl.sendMessage(msg.to,"None")
                        pass
                    for jj in matched_list:
                      try:
                         kicker=random.choice(KAC)
                         kicker.kickoutFromGroup(msg.to,[jj])
                      except:
                         cl.kickoutFromGroup(msg.to,[jj])
                    cl.sendMessage(msg.to,"Ban has been kicked")
            elif pesan.startswith(respon['rname'] + " clear banlist") and helpMessage.lower() not in pesan.lower():
                periksa['banlist'] = {}
                with open('settingan.json', 'w') as fp:
                    json.dump(periksa, fp, sort_keys=True, indent=4)
                cl.sendMessage(msg.to,"ALL BANLIST DELETED")
            elif pesan.startswith(respon['rname'] + " clear target") and helpMessage.lower() not in pesan.lower():
                periksa['target'] = {}
                with open('settingan.json', 'w') as fp:
                    json.dump(periksa, fp, sort_keys=True, indent=4)
                cl.sendMessage(msg.to,"ALL TARGET DELETED")
            elif "Gcreator" == pesan:
              if msg.toType == 2:
                g = cl.getGroup(msg.to)
                gc = g.creator.mid
                gn = g.creator.displayName
               # msg.contentType = 13
                msg.text = ""
                msg.contentMetadata = {'mid': gc}
                cl.sendMessage(msg.to,"This group has been created by "+str(gn))
                cl.sendMessage(msg.to,'',msg.contentMetadata,13)
            elif "pgroup " in pesan.lower() and helpMessage.lower() not in pesan.lower():
                xpesan = pesan.lower()
                G = xpesan.replace('Pgroup ','')
                gid = cl.getGroupIdsJoined()
                for i in gid:
                    h = cl.getGroup(i).name
                    gna = cl.getGroup(i)
                if h == G:
                    cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+ gna.pictureStatus)
            elif ".user.lock" in pesan.lower() and helpMessage.lower() not in pesan.lower():
                    if msg.contentMetadata is not None:
                        targets = []
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                               M = Message()
                               M.to = msg.to
                               #M.contentType = 13
                               M.contentMetadata = {'mid': target}
                               cl.sendMessage(msg.to, "User identifier :" + target + "\n\nUser Name : " + cl.getContact(target).displayName)
                               profile = cl.getContact(target)
                               cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                               cl.sendMessage(msg.to,'',M.contentMetadata,13)
                    else:
                        pass
            elif pesan in [".user.id"] and helpMessage.lower() not in pesan.lower():
                    if msg.contentMetadata is not None:
                        targets = []
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                               M = Message()
                               M.to = msg.to
                               M.contentType = 13
                               M.contentMetadata = {'mid': target}
                               cl.sendMessage(msg.to, "User identifier:" + target + "\n\nUser Name : " + cl.getContact(target).displayName)
                               #profile = cl.getContact(target)
                               #cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                    else:
                        pass
            elif ".whois " in pesan and helpMessage.lower() not in pesan.lower():
                if msg.toType == 2:
                    print ("Ok")
                    _name = pesan.replace(".whois ","")
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendMessage(msg.to,"Not found.")
                    else:
                        for target in targets:
                            try:
                                M = Message()
                                M.to = msg.to
                                M.contentType = 13
                                M.contentMetadata = {'mid': target}
                                cl.sendMessage(msg.to, "* User identifier: " + target + "\n\n* User Name: " + cl.getContact(target).displayName + "\n\nâ« User statusï¼ " + cl.getContact(target).statusMessage)
                            except:
                                pass
            elif "change message:" in pesan.lower() and helpMessage.lower() not in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("change message:","")
                periksa['message'] = xres
                cl.sendMessage(msg.to,"Message changed to "+xres)
            elif "message cek" in pesan.lower() and helpMessage.lower() not in pesan.lower():
                if periksa['message'] == "":
                    cl.sendMessage(msg.to,"None")
                else:
                    cl.sendMessage(msg.to,"Message : \n"+str(periksa['message']))
            elif pesan.startswith(respon['rname'] + " clone @") and helpMessage.lower() not in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            cl.cloneContactProfile(mention['M'])
                            cl.sendMessage(msg.to,"Done")
                        except Exception as error:
                            print (error)
            elif pesan.startswith(respon['rname'] + " restore") and helpMessage.lower() not in pesan.lower():
                cl.updateProfilePicture(profile.pictureStatus)
                cl.updateProfile(profile)
                cl.sendMessage(msg.to,"Restore succes")							
            elif "gift1" == pesan.lower() and helpMessage.lower() not in pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'2821',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'4'}
                msg.text = None
                cl.sendMessage(msg.to,msg.text,msg.contentMetadata,msg.contentType)
            elif "gift2" == pesan.lower() and helpMessage.lower() not in pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'3172',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'2'}
                msg.text == None
                cl.sendMessage(msg.to,msg.text,msg.contentMetadata,msg.contentType)
            elif "gift3" == pesan.lower() and helpMessage.lower() not in pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'4333',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'3'}
                msg.text = None
                cl.sendMessage(msg.to,msg.text,msg.contentMetadata,msg.contentType)
            elif "gift4" == pesan.lower() and helpMessage.lower() not in pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'3002',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'4'}
                msg.text = None
                cl.sendMessage(msg)
            elif "gift5" == pesan.lower() and helpMessage.lower() not in pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'6083',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'1'}
                msg.text = None
                cl.sendMessage(msg.to,msg.text,msg.contentMetadata,msg.contentType)
            elif pesan.startswith(respon['rname'] + " vn ") and helpMessage.lower() not in pesan.lower():
                xres = pesan.replace(respon['rname'] + " vn ","")
                tts = gTTS(text=xres, lang='id')
                path = '%s/pythonLine-vn.data' % (tempfile.gettempdir())
                ac = tts.save(path)
                cl.sendAudio(msg.to,path)
                os.remove(path)
            elif hTagall == pesan.lower() and helpMessage.lower() not in pesan.lower():
                    group = cl.getGroup(msg.to)
                    nama = [contact.mid for contact in group.members]
                    nm1,nm2,nm3,nm4,nm5,jml = [],[],[],[],[],len(nama)
                    if jml <=100:
                        MENTION(msg.to,nama)
                    elif jml > 100 and jml < 200:
                        for i in range(0,100):
                            nm1 += [nama[i]]
                        MENTION(msg.to,nm1)
                        for i in range(100,len(nama)-1):
                            nm2 += [nama[i]]
                        MENTION(msg.to,nm2)
                    elif jml > 200 and jml < 300:
                        for i in range(0,100):
                            nm1 += [nama[i]]
                        MENTION(msg.to,nm1)
                        for i in range(100,200):
                            nm2 += [nama[i]]
                        MENTION(msg.to,nm2)
                        for i in range(200,len(nama)-1):
                            nm3 += [nama[i]]
                        MENTION(msg.to,nm3)
                    elif jml > 300 and jml < 400:
                        for i in range(0,100):
                            nm1 += [nama[i]]
                        MENTION(msg.to,nm1)
                        for i in range(100,200):
                            nm2 += [nama[i]]
                        MENTION(msg.to,nm2)
                        for i in range(200,300):
                            nm3 += [nama[i]]
                        MENTION(msg.to,nm3)
                        for i in range(300,len(nama)-1):
                            nm4 += [nama[i]]
                        MENTION(msg.to,nm4)
                    elif jml > 400 and jml < 500:
                        for i in range(0,100):
                            nm1 += [nama[i]]
                        MENTION(msg.to,nm1)
                        for i in range(100,200):
                            nm2 += [nama[i]]
                        MENTION(msg.to,nm2)
                        for i in range(200,300):
                            nm3 += [nama[i]]
                        MENTION(msg.to,nm3)
                        for i in range(300,400):
                            nm4 += [nama[i]]
                        MENTION(msg.to,nm4)
                        for i in range(400,len(nama)-1):
                            nm5 += [nama[i]]
                        MENTION(msg.to,nm5)
                    
            
                      
            elif pesan.startswith(respon['rname'] + " mcast "):
                xres = pesan.replace(respon['rname'] + " mcast ","")
                group = cl.getGroup(msg.to)
                mem = [contact.mid for contact in group.members]
                cmem = cl.getContacts(mem)
                nc = ""
                for x in range(len(cmem)):
                  try:
                    cl.sendMessage(cmem[x].mid,xres)
                    nc += "\n" + cmem[x].displayName
                  except:
                    pass
                pass
                cl.sendMessage(msg.to,"Success BC to :\n%s\n\nTotal Members: %s"%(nc,str(len(cmem))))
            elif "Say " in pesan:
                xres = pesan.replace("Say ","")
                cl.sendMessage(msg.to,xres)
            elif pesan.startswith(respon['rname'] + " gcast "):
                xres = pesan.replace(respon['rname'] + " gcast ","")
                G = cl.getGroupIdsJoined()
                cgroup = cl.getGroups(G)
                ngroup = ""
                for x in range(len(cgroup)):
                    cl.sendMessage(cgroup[x].id,xres)
                    ngroup += "\n" + cgroup[x].name
                pass
                cl.sendMessage(msg.to,"Success BC to :\n%s\n\nTotal Group: %s"%(ngroup,str(len(cgroup))))
            elif pesan.startswith(respon['rname'] + " pmcast "):
                xres = pesan.replace(respon['rname'] + " pmcast ","")
                C = cl.getAllContactIds()
                cmem = cl.getContacts(C)
                nc = ""
                for x in range(len(cmem)):
                    cl.sendMessage(cmem[x].mid,xres)
                    nc += "\n" + cmem[x].displayName
                pass
                cl.sendMessage(msg.to,"Success BC to :\n%s\n\nTotal Contact: %s"%(nc,str(len(cmem))))
            elif "Ping" == pesan:
                try:
                    cl.findAndAddContactsByMid(msg.to)
                except:
                    pass
                cl.sendMessage(msg.to,"pong")
            elif pesan.startswith(respon['rname'] + " mid @") and helpMessage.lower() not in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                           cl.sendMessage(msg.to,str(mention['M']))
                        except Exception as e:
                            pass
            elif pesan.startswith(respon['rname'] + " status @") and helpMessage.lower() not in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = cl.getContact(mention['M'])
                            cl.sendMessage(msg.to,str(profile.statusMessage))
                        except Exception as e:
                            print (e)
            elif pesan.startswith(respon['rname'] + " name @") and helpMessage.lower() not in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = cl.getContact(mention['M'])
                            cl.sendMessage(msg.to,str(profile.displayName))
                        except Exception as e:
                            pass
            elif pesan.startswith(respon['rname'] + " pp @") and helpMessage.lower() not in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = cl.getContact(mention['M'])
                            cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                        except Exception as e:
                            pass
            elif pesan.startswith(respon['rname'] + " cover @") and helpMessage.lower() not in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            image = cl.getProfileCoverURL(mention['M'])
                            #kk.sendImage(msg.to,image)
                            cl.sendImageWithURL(msg.to,image)
                        except Exception as e:
                            pass
            elif "reboot" == pesan.lower() and helpMessage.lower() not in pesan.lower():
                cl.sendMessage(msg.to,"Rebooting!!")
                restart_program()

            elif "me ticket" in pesan.lower() and helpMessage.lower() not in pesan.lower():
                tiket = cl._reissueUserTicket()
                cl.sendMessage(msg.to, "line.me/ti/p/%20"+tiket)
            elif "Look:" in pesan:
                   umid = pesan.replace('Look:','')
                   msg.contentType = 13
                   msg.text = None
                   msg.contentMetadata = {'mid': umid}
                   cl.sendMessage(msg)
            elif "Gift" in pesan:
                xres = pesan.replace("Gift","")
                if xres in helpMessage:
                    pass
                elif xres == "":
                    cl.sendMessage(msg.to,"Invalid input")
                else:
                    try:
                      number = int(xres)
                    except:
                        cl.sendMessage(msg.to,"Invalid input")
                        
                    for x in range(0,number):
                        try:
                           msg.contentType = 9
                           msg.contentMetadata = { 'STKPKGID':'2821',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'4'}
                           msg.text = None
                           cl.sendMessage(msg)
                        except:
                            pass
            elif "Spam mc:" in pesan:
                xres = pesan.replace("Spam mc:","")
                if xres in helpMessage:
                    pass
                elif xres == "":
                    pass
                else:
                    periksa['chatspam'] = xres
                    with open('settingan.json', 'w') as fp:
                            json.dump(periksa, fp, sort_keys=True, indent=4)
                    cl.sendMessage(msg.to,"Chat for mc: %s"%(xres))
            elif "Group spam:" in pesan:
                xres = pesan.replace("Group spam:","")
                if xres in helpMessage:
                    pass
                elif xres == "":
                    pass
                else:
                    periksa['gsname'] = xres
                    with open('settingan.json', 'w') as fp:
                            json.dump(periksa, fp, sort_keys=True, indent=4)
                    cl.sendMessage(msg.to,"Group name for spam inv: %s"%(xres))
            elif "spam mc on" == pesan.lower() and helpMessage.lower() not in pesan.lower():
                if periksa["target"] == {}:
                    cl.sendMessage(msg.to,"Target tidak ada")
                else:
                   mc = []
                   for mi_d in periksa["target"]:
                        mc.append(mi_d)
                   pass
                   kk.findAndAddContactsByMids(mc)
                   wb.findAndAddContactsByMids(mc)
                   cl.sendMessage(msg.to,"Starting....")
                   try:
                     kk.sendMessage(msg.to,"Starting....")
                   except:
                       pass
                   try:
                     wb.sendMessage(msg.to,"Starting....")
                   except:
                       pass
                   for zx in range(0,100):
                     try:
                       room = cl.createRoom(mc)
                       roomId = room.mid
                       print (roomId)
                       for i in range(0,10):
                         print ('sendPesan')
                         cl.sendMessage(roomId,"%s"%(periksa['chatspam']))
                       cl.leaveRoom(roomId)
                     except Exception as E:
                         print (E)
                     try:
                       room = kk.createRoom(mc)
                       roomId = room.mid
                       print (roomId)
                       for i in range(0,10):
                           print ('sendPesan')
                           kk.sendMessage(roomId,"%s"%(periksa['chatspam']))
                       kk.leaveRoom(roomId)
                     except:
                         pass
                     try:
                       room = wb.createRoom(mc)
                       roomId = room.mid
                       print (roomId)
                       for i in range(0,10):
                           print ('sendPesan')
                           wb.sendMessage(roomId,"%s"%(periksa['chatspam']))
                       wb.leaveRoom(roomId)
                     except:
                         pass
                   cl.sendMessage(msg.to,"Done")
                   try:
                     kk.sendMessage(msg.to,"Done")
                   except:
                       pass
                   try:
                     wb.sendMessage(msg.to,"Done")
                   except:
                       pass
            elif "spam inv on" == pesan.lower() and helpMessage.lower() not in pesan.lower():
                if periksa["target"] == {}:
                    cl.sendMessage(msg.to,"Target tidak ada")
                else:
                   mc = []
                   for mi_d in periksa["target"]:
                        mc.append(mi_d)
                   pass
                   cl.findAndAddContactsByMids(mc)
                   cl.sendMessage(msg.to,"Starting....")
                   for zx in range(0,400):
                      try:
                        cl.createGroup(periksa['gsname'],mc)
                      except:
                         pass
                   cl.sendMessage(msg.to,"Done")
                   cl.sendMessage(msg.to,"Loading result...")
                   G = cl.getGroupIdsJoined()
                   cgroup1 = cl.getGroups(G)
                   ngroup1 = []
                   for x in range(len(cgroup1)):
                       if cgroup1[x].name == periksa['gsname']:
                          ngroup1.append(cgroup1[x].name)
                   cl.sendMessage(msg.to,"Success spam %s groups to target"%(len(ngroup1)))
            elif (respon['sname'] + " spam " in pesan):
                   lol = pesan.replace(respon['sname'] + " spam ",'')
                   hehe = lol.split("@")
                   cl.sendMessage(msg.to,"Spamming >> "+str(hehe[1])+"\nGroups Name:"+str(hehe[0]))
                   kk.findAndAddContactsByMid(hehe[1])
                   wb.findAndAddContactsByMid(hehe[1])
                   for zx in range(0,400):
                     try:
                       cl.createGroup(str(hehe[0]),[hehe[1]])
                     except:
                         pass
                   cl.sendMessage(msg.to,"Done")

            elif (respon['sname'] + " leave " in pesan):
                group_name = pesan.replace(respon['sname'] + " leave ",'')
                G = cl.getGroupIdsJoined()
                cgroup = cl.getGroups(G)
                for x in range(len(cgroup)):
                  if group_name == cgroup[x].name:
                      try:
                         cl.leaveGroup(cgroup[x].id)
                      except:
                          pass
                cl.sendMessage(msg.to,"Done")
                   

            elif (respon['rname'] + " Ban room " in pesan):  
                 nk0 = pesan.replace(respon['rname'] + " Ban room ","")
                 nk1 = nk0.lstrip()
                 nk2 = nk1.replace("","")
                 nk3 = nk2.rstrip()
                 _name = nk3
                 gs = cl.getGroup(msg.to)
                 targets = []
                 for s in gs.members:
                     if _name in s.displayName:
                        targets.append(s.mid)
                 if targets == []:
                     sendMessage(msg.to,"user does not exist")
                     pass
                 else:
                     for target in targets:
                         try:
                            periksa["banlist"][target] = True
                            cl.sendMessage(msg.to, cl.getContact(target).displayName + " Add to Blacklist")
                         except:
                            cl.sendMessage(msg.to,"error")
            elif (respon['rname'] + " unban room " in pesan):  
                 nk0 = pesan.replace(respon['rname'] + " unban room ","")
                 nk1 = nk0.lstrip()
                 nk2 = nk1.replace("","")
                 nk3 = nk2.rstrip()
                 _name = nk3
                 gs = cl.getGroup(msg.to)
                 targets = []
                 for s in gs.members:
                     if _name in s.displayName:
                        targets.append(s.mid)
                 if targets == []:
                     sendMessage(msg.to,"user does not exist")
                     pass
                 else:
                     for target in targets:
                         try:
                            del periksa["banlist"][target]
                            cl.sendMessage(msg.to,cl.getContact(target).displayName + " Remove to Blacklist")
                         except:
                            cl.sendMessage(msg.to,"error")
            elif (respon['rname'] + " ban " in pesan):                  
                       nk0 = pesan.replace(respon['rname'] + " ban ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    periksa["banlist"][target] = True
                                    cl.sendMessage(msg.to,"")
                                except:
                                    cl.sendMessage(msg.to,"Error")

            elif (respon['rname'] + " unban " in pesan):                  
                       nk0 = pesan.replace(respon['rname'] + " unban ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    del periksa["banlist"][target]
                                    cl.sendMessage(msg.to,"Target Unlocked")
                                except:
                                    cl.sendMessage(msg.to,"Error") 
#===============[Tranlate Command]====================
            elif "Translate" == pesan:
                try:
                  cl.sendMessage(msg.to,"List Command Translate:\n\n Tr-id to Indonesia \n Tr-th to Thai \n Tr-en to English \n Tr-ja to Japan \n Tr-ms to Malay \n Tr-jw to Jawa \n Tr-it to Italia \n Tr-my to Myanmar \n Tr-fr to French \n Tr-ar to Arabic")
                except:
                   pass
            elif "Tr-id" in pesan:
                 xres = pesan.replace("Tr-id","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'id')
                 cl.sendMessage(msg.to,str(trans))
            elif "Tr-en" in pesan:
                 xres = pesan.replace("Tr-en","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'en')
                 cl.sendMessage(msg.to,str(trans))
            elif "Tr-ja" in pesan:
                 xres = pesan.replace("Tr-ja","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'ja')
                 cl.sendMessage(msg.to,str(trans))
            elif "Tr-th" in pesan:
                 xres = pesan.replace("Tr-th","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'th')
                 cl.sendMessage(msg.to,str(trans))
            elif "Tr-jw" in pesan:
                 xres = pesan.replace("Tr-jw","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'jw')
                 cl.sendMessage(msg.to,str(trans))
            elif "Tr-ar" in pesan:
                 xres = pesan.replace("Tr-ar","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'ar')
                 cl.sendMessage(msg.to,str(trans))
            elif "Tr-ms" in pesan:
                 xres = pesan.replace("Tr-ms","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'ms')
                 cl.sendMessage(msg.to,str(trans))
            elif "Tr-my" in pesan:
                 xres = pesan.replace("Tr-my","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'my')
                 cl.sendMessage(msg.to,str(trans))
            elif "Tr-it" in pesan:
                 xres = pesan.replace("Tr-it","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'it')
                 cl.sendMessage(msg.to,str(trans))
            elif "Tr-fr" in pesan:
                 xres = pesan.replace("Tr-fr","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'fr')
                 cl.sendMessage(msg.to,str(trans))

            elif (respon['rname'] + " wiki " in pesan):
                cari = pesan.replace(respon['rname'] + " wiki ","")
                wikipedia.set_lang("id")
                try:
                   ny = wikipedia.summary(cari)
                except Exception as ny:
                    print (ny)
                cl.sendMessage(msg.to,"%s"%(ny))
            elif (respon['rname'] + " urban " in pesan):
               cari = pesan.replace(respon['rname'] + " urban ","")
               try:
                 response = requests.get("http://api.urbandictionary.com/v0/define?term="+cari)
                 data = response.json()
                 num_requested = 0
                 term_list = data['list']
                 num_requested = min(num_requested, len(term_list) - 1)
                 num_requested = max(0, num_requested)
                 definition = term_list[num_requested].get('definition')
                 example = term_list[num_requested].get('example')
                 cl.sendMessage(msg.to,"Definition:\n\n%s\n\nExample:\n\n%s"%(definition,example))
               except:
                 cl.sendMessage(msg.to,"Error")
                
            elif (respon['rname'] + " ig pic " in pesan):
               cari = pesan.replace(respon['rname'] + " ig pic ","")
               if cari not in helpMessage:
                 try:
                   response = requests.get(cari+"?__a=1")
                   data = response.json()
                   ig_url = data['graphql']['shortcode_media']['display_url']
                   cl.sendImageWithURL(msg.to,ig_url)
                 except Exception as E:
                   cl.sendMessage(msg.to,"Error\n%s"%(E))
            elif (respon['rname'] + " ig vid " in pesan):
               cari = pesan.replace(respon['rname'] + " ig vid ","")
               if cari not in helpMessage:
                 try:
                   response = requests.get(cari+"?__a=1")
                   data = response.json()
                   ig_url = data['graphql']['shortcode_media']['display_url']
                   cl.sendVideoWithURL(msg.to,ig_url)
                 except Exception as E:
                   cl.sendMessage(msg.to,"Error\n%s"%(E))
            elif (respon['rname'] + " all pic" in pesan) and helpMessage.lower() not in pesan.lower():
                if msg.toType == 2:
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if g.mid not in Bots:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendMessage(msg.to,"Target not found")
                    else:
                        for target in targets:
                            try:
                                profile = cl.getContact(target)
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                            except:
                                pass
#===============[Assist Command]====================
            elif "Gn " in pesan:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.name = msg.text.replace("Gn ","")
                    cl.updateGroup(X)
                    cl.sendText(msg.to,"Group name change to " + X.name)
            elif rname + " status " in pesan:
              xres = pesan.replace(rname + " upstatus ","")
              if len(xres) <= 500:
                profile = cl.getProfile()
                profile.statusMessage = xres
                cl.updateProfile(profile)
                cl.sendMessage(msg.to,"Status changed to " + xres)
                
            elif rname + " pname " in pesan:
              xres = pesan.replace(rname + " pname ","")
              if len(xres) <= 20:
                profile = cl.getProfile()
                profile.displayName = xres
                cl.updateProfile(profile)
                cl.sendMessage(msg.to,"Name changed to " + xres)
                
            elif "selftime" in pesan.lower() and helpMessage.lower() not in pesan.lower():
                elpsd = datetime.now() - strt
                cl.sendMessage(msg.to,'Duration : %s'%(elpsd))
            elif (respon['rname'] + " backup" in pesan) or (respon['sname'] + " backup" in pesan):
                cl.updateProfilePicture(profile.pictureStatus)
                cl.updateProfile(profile)
                cl.sendMessage(msg.to, "Done")
#============================================NEW COMMAND===============================================#
            elif pesan.startswith(respon['rname'] + " reinvite"):
                if msg.toType == 2:
                    g = cl.getGroup(msg.to)
                    if g.invitee is not None:
                        gInviMids = [contact.mid for contact in g.invitee]
                        cl.cancelGroupInvitation(msg.to, gInviMids)
                        cl.inviteIntoGroup(msg.to, gInviMids)
            elif pesan.startswith(respon['rname'] + " copypp"):
                if msg.contentMetadata is not None:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        cl.copyPictureProfile(target)
                        cl.sendMessage(msg.to,"Succes coppy")
                else:
                    pass
            elif pesan.startswith(respon['rname'] + " copycv"):
                if msg.contentMetadata is not None:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        image = cl.getProfileCoverURL(target)
                        #image = cl.getProfileDetail(msg.to)
                        cl.updateProfileCover(image)
                        cl.sendMessage(msg.to,"DONE")
                else:
                    pass
                
            elif pesan.startswith(respon['rname'] + " pic "):
                xpesan = pesan.replace(respon['rname'] + " pic ","")
                img = cl.downloadFileURL(xpesan)
                cl.updateProfilePicture(img)
                cl.sendMessage(msg.to,"Profile image updated")
#===================================================================COVER============================================================#
            elif pesan.startswith(rname + " update cover "):
                xpesan = pesan.replace(rname + " update cover ","")
                img = cl.downloadFileURL(xpesan)
                cl.updateProfileCover(img)
                cl.sendMessage(msg.to,"Cover image updated")
#=======================================================================================================#
            elif (respon['rname'] + " respon " in pesan):
                xres = pesan.replace(respon['rname'] + " respon ","")
                if xres == "off":
                    periksa['mention2'] = False
                    with open('settingan.json', 'w') as fp:
                         json.dump(periksa, fp, sort_keys=True, indent=4)
                    cl.sendMessage(msg.to,"Notag is Disabled")
                elif xres == "on":
                    periksa['mention2'] = True
                    with open('settingan.json', 'w') as fp:
                         json.dump(periksa, fp, sort_keys=True, indent=4)
                    cl.sendMessage(msg.to,"Notag is Enabled")

            elif (respon['rname'] + " respon." in pesan):
                xres = pesan.replace(respon['rname'] + " respon.","")
                if xres == "off":
                    periksa['mention3'] = False
                    cl.sendMessage(msg.to,"Auto respon is Disabled")
                elif xres == "on":
                    periksa['mention3'] = True
                    cl.sendMessage(msg.to,"Auto respon is Enabled")
                    
            elif (respon['rname'] + " update.respon." in pesan):
                c = pesan.replace(respon['rname'] + " update.respon.","")
                if c in [""," ","\n",None]:
                    with open('settingan.json', 'w') as fp:
                         json.dump(periksa, fp, sort_keys=True, indent=4)
                    cl.sendMessage(msg.to,"the character string which can't be changed.")
                else:
                    periksa["respon"] = c
                    with open('settingan.json', 'w') as fp:
                         json.dump(periksa, fp, sort_keys=True, indent=4)
                    cl.sendMessage(msg.to,"It Is Respon:\n\n" + c)
#=======================================================================================================#
            elif (respon['rname'] + " gpicture" in pesan):
                group = cl.getGroup(msg.to)
                path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                cl.sendImageWithURL(msg.to,path)

            elif pesan.startswith(rname + " change gpict "):
                xpesan = pesan.replace(rname + " change gpict ","")
                group = cl.getGroup(msg.to)
                img = cl.downloadFileURL(xpesan)
                cl.updateGroupPicture(img)
                cl.sendMessage(msg.to,"group image updated")
#=======================================================================================================#
            elif (respon['rname'] + " myhelp" in pesan) or (respon['sname'] + " myhelp" in pesan):
                commandlist = "⊰❉⊱ ✍ŤẸÃϻ Ж ĤÃЌβỖŤ✈ ⊰❉⊱\n"
                listcommand = [' responsename',' update rname',' update sname',' namelock:on/off',' iconlock:on',' update welcome',' welcome:on/off',' update pic',' spam [@]',' comment [text]',' add; [emoji]',' con [text]',' youtube [text]',' music [text]',' lyric [text]',' autojoin:on/off',' autolike:on/off',' autoadd:on/off',' allowban:on/off',' mc:on/off',' qr:on/off',' cancelall:on/off',' protection:on/off',' pjoin:on/off',' protectmax:on/off',' setting',' mc add [@]',' mc del [@]',' reject:on/off',' refuse all',' lurk:on/off',' lurkers',' group',' leave all',' look [mid]',' search [@]',' gid',' myid',' wl:on/off',' unwl:on/off',' join [link group]',' gift:on',' gift:on:[jumblh]',' ban:repeat',' unban:repeat',' target:repeat',' deltarget:repeat',' repeat:off',' add wl @',' del wl @',' add ban @',' del ban @',' add target @',' del taget @',' targetlist',' banlist',' cek ban',' ban user',' whitelist',' wl user',' mc target',' wban [text]',' wunban [text]',' wbanlist',' void',' talkban [@]',' contact:on/off',' tunban [@]',' purge',' wiki',' urban',' ats',' translate',' copy',' restore',' runing',' all pic',' ig pic',' ig vid',' vn [text]',' music [text]',' lyric',' comment [text]',' membercast',' groupcast',' pmcast',' image @',' name @',' status @',' cover @',' mid',' group spam:[text]',' spam inv:on',' pic[URLlink]',' update image',' gpicture',' image [text]',' join',' @bye',' kickkall\n']
                listcommand = ["❉ "+rname + o for o in listcommand]
                for cmd in listcommand:
                    commandlist +="\n%s"%cmd
                cl.sendMessage(msg.to,commandlist)
#========================================WIKI=============================================#
           # elif pesan .startswith(respon["rname"]+' ig '):
           #     ig = pesan.replace(respon["rname"]+' ig ','')
           #     html = requests.get('https://www.ig.com/' + ig + '/')
           #     soup = BeautifulSoup(html.text, 'html5lib')
           #     data = soup.find_all('meta', attrs={'property':'og:description'})
           #     text = data[0].get('content').split()
           #     data1 = soup.find_all('meta', attrs={'property':'og:image'})
           #     text1 = data1[0].get('content').split()
           #     user = "Name: " + text[-2] + "\n"
           #     user1 = "Username: " + text[-1] + "\n"
           #     followers = "Followers: " + text[0] + "\n"
           #     following = "Following: " + text[2] + "\n"
           #     post = "Post: " + text[4] + "\n"
           #     link = "Link: " + "https://www.ig.com/" + ig
           #     detail = "========ig INFO USER========\n"
           #     details = "\n========ig INFO USER========"
           #     cl.sendMessage(msg.to, detail + user + user1 + followers + following + post + link + details)
           #     cl.sendImageWithURL(msg.to, text1[0])
                
            elif pesan .startswith(respon["rname"]+' wik '):
                wiki = pesan.replace(respon["rname"]+' wik ','')
                wiki.set_lang("id")
                pesan="Title ("
                pesan+=wiki.page(wiki).title
                pesan+=")\n\n"
                pesan+=wiki.summary(wiki, sentences=1)
                pesan+="\n"
                pesan+=wiki.page(wiki).url
                cl.sendMessage(msg.to, pesan)
#==============================================================IMAGE GOOGLE==========================================================#
            elif pesan .startswith(respon["rname"]+' image '):
                xres = pesan.replace(respon["rname"]+' image ','')
                url = 'https://www.google.com/search?hl=en&biw=1366&bih=659&tbm=isch&sa=1&ei=vSD9WYimHMWHvQTg_53IDw&q=' + xres
                raw_html = (download_page(url))
                items = []
                items = items + (_images_get_all_items(raw_html))
                path = random.choice(items)
                try:
                    start = timeit.timeit()
                    cl.sendImageWithURL(msg.to,path)
                   # cl.sendMessage(msg.to, "「Google Image」\nType: Search Image\nTime taken: %s" % (start) +"\nTotal Image Links = "+str(len(items)))
                except Exception as e:
                    cl.sendMessage(msg.to, str(e))
#==========================================================PM CONTACT===================================================================#
            elif pesan.startswith(respon['rname'] + " pm"):
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]
                mi = cl.getContacts(key1)
                xres = pesan.replace(respon['rname'] + " pm","")
                for x in range(len(mi)):
                    cl.sendMessage(mi[x].mid,xres)
                pass
                cl.sendMessage(msg.to,"Done")
#================================================================KICK USER=================================================================#
            elif (respon['rname'] + " vkick" in pesan):
                if msg.contentMetadata is not None:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        cl.findAndAddContactsByMid(target)
                        cl.kickoutFromGroup(msg.to, target)
                        cl.inviteIntoGroup(msg.to, target)
                        cl.cancelGroupInvitation(msg.to, target)
                else:
                    pass
            elif pesan.startswith(respon['rname'] + " kick"):
                if msg.contentMetadata is not None:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        cl.kickoutFromGroup(msg.to, target)
                else:
                    pass

            #elif hKick+ " " in pesan.lower() and helpMessage.lower() not in pesan.lower():
            elif pesan.startswith(respon['sname'] + " kick @"):
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            cl.kickoutFromGroup(msg.to, [mention['M']])
                        except:
                            pass

            #elif hKill+ " " in pesan.lower() and helpMessage.lower() not in pesan.lower():
            elif pesan.startswith(respon['sname'] + " vkick @"):
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            cl.findAndAddContactsByMid(mention['M'])
                            cl.kickoutFromGroup(msg.to, [mention['M']])
                            cl.inviteIntoGroup(msg.to, [mention['M']])
                            cl.cancelGroupInvitation(msg.to, [mention['M']])
                        except Exception as error:
                            print (error)
                            try:
                                kk.findAndAddContactsByMid(mention['M'])
                                kk.kickoutFromGroup(msg.to, [mention['M']])
                                kk.inviteIntoGroup(msg.to, mention['M'])
                                kk.cancelGroupInvitation(msg.to, [mention['M']])
                            except:
                                pass
#=================================================KICKALL====================================================#
            elif pesan.startswith(respon['sname'] + " kickall"):
                _name = pesan.replace(respon['sname'] + " kickall")
                gs = cl.getGroup(msg.to)
                cl.sendMessage(msg.to,"「 Kickkal 」\nKickall is STARTING♪\n'abort' to abort ♪""")
                cl.sendMessage(msg.to,"「 Kickkal 」\n %i Do you fuck you bro♪\n/ˌOlalala Olalala/" % len(gs.members))
                targets = []
                for g in gs.members:
                    if _name in g.displayName:
                        targets.append(g.mid)
                for target in targets:
                    if not target in Bots:
                        try:
                            kicker=random.choice(KAC)
                            kicker.kickoutFromGroup(msg.to,[target])
                            print (msg.to,[g.mid])
                        except:
                            cl.sendMessage(msg.to,"「 Kickkal 」\nKickall is STARTING♪\n'abort' to abort ♪""")
                            cl.sendMessage(msg.to,"「 Kickkal 」\n %i Do you fuck you bro♪\n/ˌOlalala Olalala/" % len(gs.members))
                    else:
                        pass
#===============================================================NOTE============================================================#
            elif "Note " in pesan:
                xres = pesan.replace("Note ","")
                gs = cl.getGroup(msg.to)
                cl.createGroupPost(xres)
                cl.sendMessage(msg.to, 'Add Note ' + xres)
            elif pesan.startswith(respon["rname"]+' ig '):
                    ig = pesan.replace(respon["rname"]+' ig ','')
                    html = requests.get('https://www.ig.com/' + ig + '/')
                    soup = BeautifulSoup(html.text, 'html5lib')
                    data = soup.find_all('meta', attrs={'property':'og:description'})
                    text = data[0].get('content').split()
                    data1 = soup.find_all('meta', attrs={'property':'og:image'})
                    text1 = data1[0].get('content').split()
                    user = "Name: " + text[-2] + "\n"
                    user1 = "Username: " + text[-1] + "\n"
                    followers = "Followers: " + text[0] + "\n"
                    following = "Following: " + text[2] + "\n"
                    post = "Post: " + text[4] + "\n"
                    link = "Link: " + "https://www.ig.com/" + ig
                    detail = "========ig INFO USER========\n"
                    details = "\n========ig INFO USER========"
                    cl.sendMessage(msg.to, detail + user + user1 + followers + following + post + link + details)
                    cl.sendImageWithURL(msg.to, text1[0])
#==============================================================DATE=============================================================#
            elif pesan in ['Date']:
                cl.sendMessage(msg.to, " Tanggal " + datetime.now().strftime('%d/%m/%y Jam Is %H:%M:%S') )
            elif pesan.startswith(respon['rname'] + " byeme"):
                if msg.toType == 2:
                    gs = cl.getGroup(msg.to)
                    try:
                        cl.sendMessage(msg.to,"Bye Bye!!\n\n ["  +  str(gs.name)  + "]")
                        cl.leaveGroup(msg.to)
                    except:
                        pass
#===============================================================wordban============================================================#
            elif pesan.startswith(rname+" wordban "):
                wban = pesan.replace(rname+" wordban ","").lstrip().rstrip()
                wbanlist.append(wban)
                cl.sendMessage(msg.to,"%s Message banned."%wban)

            elif pesan.startswith(rname+" delwordban "):
                wuban = pesan.replace(rname+" delwordban ","").lstrip().rstrip()
                if wuban in wbanlist:
                    wbanlist.remove(wuban)
                    cl.sendMessage(msg.to,"%s Message no banned."%wuban)
                else:
                    cl.sendMessage(msg.to,"%s Message not banned."%wuban)

            elif pesan.startswith(rname+" wordbanlist"):
                tst = "Wordbanlist:\n"
                if len(wbanlist) > 0:
                    for word in wbanlist:
                        tst += "☠- %s"%word
                    cl.sendMessage(msg.to,tst)
                else:
                    cl.sendMessage(msg.to,"Wordbanlist Noting!")
#===============================================================picture============================================================#
            elif 'scover' in pesan.lower():
                try:
                    key = eval(msg.contentMetadata["MENTION"])
                    u = key["MENTIONEES"][0]["M"]
                    a = cl.getProfileCoverURL(mid=u)
                    print(a)
                    cl.sendImageWithURL(msg.to, a)
                except Exception as e:
                    print(e)
            elif pesan in ['Pc']:
                contact = cl.getContact(msg.to)
                path =("http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                cl.sendImageWithURL(msg.to, path)

            elif pesan in ['Cv']:
                contact = cl.getContact(msg.to)
                h = cl.getProfileDetail(msg.to)
                objId = h["result"]["objectId"]
                cl.sendImageWithURL(msg.to, "http://dl.profile.line-cdn.net/myhome/c/download.nhn?userid=" + msg.to + "&oid="+ objId)

            elif "Pap set:" in pesan:
                periksa["pic"] = pesan.replace("Pap set:","")
                cl.sendMessage(msg.to, "Pic has been set to")
                
            elif pesan in ["Pap"]:
                cl.sendImageWithURL(msg.to,periksa["pic"])

#------------------------
            elif '/ig ' in pesan.lower():
                    try:
                        instagram = pesan.replace("/ig ","")
                        response = requests.get("https://www.instagram.com/"+instagram+"?__a=1")
                        data = response.json()
                        namaIG = str(data['user']['full_name'])
                        bioIG = str(data['user']['biography'])
                        mediaIG = str(data['user']['media']['count'])
                        verifIG = str(data['user']['is_verified'])
                        usernameIG = str(data['user']['username'])
                        followerIG = str(data['user']['followed_by']['count'])
                        profileIG = data['user']['profile_pic_url_hd']
                        privateIG = str(data['user']['is_private'])
                        followIG = str(data['user']['follows']['count'])
                        link = "Link: " + "https://www.instagram.com/" + instagram
                        detail = "========INSTAGRAM INFO USER========\n"
                        details = "\n========INSTAGRAM INFO USER========"
                        text = detail + "Name : "+namaIG+"\nUsername : "+usernameIG+"\nBiography : "+bioIG+"\nFollower : "+followerIG+"\nFollowing : "+followIG+"\nPost : "+mediaIG+"\nVerified : "+verifIG+"\nPrivate : "+privateIG+"" "\n" + link + details
                        cl.sendImageWithURL(msg.to, profileIG)
                        cl.sendText(msg.to, str(text))
                    except Exception as e:
                        cl.sendText(msg.to, str(e))
                        cl.sendText(msg.to,"Follow Fast Follback")

#======================================
            elif pesan.startswith(respon['rname'] + " ig"):
                    try:
                        instagram = pesan.replace(respon['rname'] + " ig","")
                        response = requests.get("https://www.instagram.com/"+instagram+"?__a=1")
                        data = response.json()
                        namaIG = str(data['user']['full_name'])
                        bioIG = str(data['user']['biography'])
                        mediaIG = str(data['user']['media']['count'])
                        verifIG = str(data['user']['is_verified'])
                        usernameIG = str(data['user']['username'])
                        followerIG = str(data['user']['followed_by']['count'])
                        profileIG = data['user']['profile_pic_url_hd']
                        privateIG = str(data['user']['is_private'])
                        followIG = str(data['user']['follows']['count'])
                        link = "Link: " + "https://www.instagram.com/" + instagram
                        detail = "========INSTAGRAM INFO USER========\n"
                        details = "\n========INSTAGRAM INFO USER========"
                        text = detail + "Name : "+namaIG+"\nUsername : "+usernameIG+"\nBiography : "+bioIG+"\nFollower : "+followerIG+"\nFollowing : "+followIG+"\nPost : "+mediaIG+"\nVerified : "+verifIG+"\nPrivate : "+privateIG+"" "\n" + link + details
                        cl.sendImageWithURL(msg.to, profileIG)
                        cl.sendText(msg.to, str(text))
                    except Exception as e:
                        cl.sendText(msg.to, str(e))
                        cl.sendText(msg.to,"Follow Fast Follback")

#========================================FB
            elif "/fb" in pesan:
                    a = pesan.replace("/fb","")
                    replace = urllib.quote(a)
                    cl.sendText(msg.to,"「 Searching 」\n" "Type:Search Info\nStatus: Processing")
                    cl.sendText(msg.to, "https://www.facebook.com/search/str/"+ replace + "/keywords_search")
                    #cl.sendText(msg.to,"「 Searching 」\n" "Type:Search Info\nStatus: Success")
            elif pesan.lower().startswith("/imagetext "):
                    sep = pesan.split(" ")
                    textnya = pesan.replace(sep[0] + " ","")
                    path = "http://chart.apis.google.com/chart?chs=480x80&cht=p3&chtt=" + textnya + "&chts=FF0000,60&chf=bg,s,000000"
                    urllib.request.urlretrieve(path, "steal.png")
                    #urllib.urlretrieve(path, "steal.png")
                    cl.sendImage(msg.to,"steal.png")
#========================================INVITE
            elif pesan.startswith(rname + " invite.on"):
                inviting = True
                cl.sendText(msg.to,"Send a contact to invite.")
#========================================KICK
            elif pesan.startswith(rname + " kick.on"):
                kick = True
                cl.sendText(msg.to,"Send a contact to kick.")							
#===============================================================
            elif '/ymp3 ' in pesan:
                try:
                    textToSearch = (pesan).replace('/ymp3 ', "").strip()
                    query = urllib.parse.quote(textToSearch)
                    url = "https://www.youtube.com/results?search_query=" + query
                    response = urllib.request.urlopen(url)
                    html = response.read()
                    soup = BeautifulSoup(html, "html.parser")
                    results = soup.find(attrs={'class':'yt-uix-tile-link'})
                    dl=("https://www.youtube.com" + results['href'])
                    vid = pafy.new(dl)
                    stream = vid.streams
                    for s in stream:
                        vin = s.url
                        hasil = vid.title
                        hasil += '\n⌬ Penulis : ' + str(vid.author) + '\n⌬ Durasi : ' + str(vid.duration) + '\n⌬ Suka : ' + str(vid.likes) + '\n⌬ Penonton : ' + str(vid.viewcount) + '\n⌬ Rating : ' + str(vid.rating) + '\n⌬ Diterbitkan : ' + str(vid.published)
                    cl.sendText(msg.to,hasil)
                    cl.sendAudioWithURL(msg.to,vin)
                    print (" Yt-mp3 + mp4 Succes")
                except Exception as e:
                    cl.sendText(msg.to,str(e))
            elif "/ymp4 " in pesan:
                try:
                    textToSearch = (pesan).replace('/ymp4 ', "").strip()
                    query = urllib.parse.quote(textToSearch)
                    url = "https://www.youtube.com/results?search_query=" + query
                    response = urllib.request.urlopen(url)
                    html = response.read()
                    soup = BeautifulSoup(html, "html.parser")
                    results = soup.find(attrs={'class':'yt-uix-tile-link'})
                    dl=("https://www.youtube.com" + results['href'])
                    vid = pafy.new(dl)
                    stream = vid.streams
                    for s in stream:
                        vin = s.url
                        hasil = vid.title
                        hasil += '\n⌬ Penulis : ' + str(vid.author) + '\n⌬ Durasi : ' + str(vid.duration) + '\n⌬ Suka : ' + str(vid.likes) + '\n⌬ Penonton : ' + str(vid.viewcount) + '\n⌬ Rating : ' + str(vid.rating) + '\n⌬ Diterbitkan : ' + str(vid.published)
                    cl.sendText(msg.to,hasil)
                    cl.sendVideoWithURL(msg.to,vin)
                    print (" Yt-mp3 + mp4 Succes")
                except Exception as e:
                    cl.sendText(msg.to,str(e))

            elif "Read:" in pesan:
                    xres = pesan.replace("Read:","")
                    if xres == "off":
                        periksa['alwayRead'] = False
                        cl.sendMessage(msg.to,"Autoread Chat Disabled")
                    elif xres == "on":
                        periksa['alwayRead'] = True
                        cl.sendMessage(msg.to,"Autoread Chat Enabled")

#===============================================================CLEARSET========================================================#
        if op.type == 59:
            print (op)
    
 except Exception as e:
        cl.log("ERROR : " + str(e))
