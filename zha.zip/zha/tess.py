# -*- coding: utf-8 -*-
# Thanks for FadhiilRachman and TCR TEAM
# I JUST FORKED
from linepy import *
#import .linepy
#import time,random,requests,sys,json,codecs,threading,glob,re,datetime
from datetime import timedelta, date
import glob
import os

#cl = LineClient()
cl = LineClient(authToken='EongdMUsDhnyz0Ihx8cd.bFt/SJvuk3tVrtJBv+kGVq.ARXZGm+VjEaofPVy2FA58NMOSLVjv+Yl6vhwY/F4jiY=')
cl.log("Auth Token : " + str(cl.authToken))

# Initialize LineChannel with LineClient
channel = LineChannel(cl)
cl.log("Channel Access Token : " + str(channel.cl.authToken))

#ki = LineClient() ----> Buat Login by QR
ki = LineClient(authToken='EoHcwyLKeew1jO02jyba.KvOD7oCa8IUHCEww4ms8/G.qH4nHVN77XArHtJV38zJh65iJBJX3+CIghMQG31llAI=')
ki.log("Auth Token : " + str(ki.authToken))

# Initialize LineChannel with LineClient
#channel2 = LineChannel(ki)
#ki.log("Channel Access Token : " + str(channel2.channelAccessToken))

#kk = LineClient() ----> Buat Login by QR
#kk = LineClient(authToken='EnVcPsxBy2CQ9nA9sXxe.EgdssHRbezuQqbGeviQzFG.exXcgLdDMvJXHnBSUmThH3RdEch6oQ+CNnuH8xHQQvQ=')
#kk.log("Auth Token : " + str(kk.authToken))

# Initialize LineChannel with LineClient
#channel3 = LineChannel(kk)
#kk.log("Channel Access Token : " + str(channel3.channelAccessToken))

#kc = LineClient() ----> Buat Login by QR
#kc = LineClient(authToken='EnjDuvhZmqXF55nfvkv2.uGMAJ5dPPbeRO1cESqoRCG.HcU0jXRewpBdDMUMX9Ux7/NYOAZ78/zT0GYa0+HYkRk=')
#kc.log("Auth Token : " + str(kc.authToken))

# Initialize LineChannel with LineClient
#channel4 = LineChannel(kc)
#kc.log("Channel Access Token : " + str(channel4.channelAccessToken))

poll = LinePoll(cl)
#poll2 = LinePoll(kk)
poll3 = LinePoll(ki)
#poll4 = LinePoll(kc)

helpMessage ="""
]Id︎[
]Mid︎[
]Me︎[
]Mc[
]K on/off[
]Join on/off[
]Group cancelall︎[
]Leave︎ on/off[
]Add on/off[
]Share on/off[
]Removed]all message[
]Confirm[
]Jam on/off[
]Change clock[
]Up[
]Aple[

]Curl[
]Ourl[
]url[
[Ginfo]
]Cancel[
]Gn 「group name」[

[Bye[
]All group[
]Jepit[
]Usir @[
]Pancal @[
]Kill ban[
]Rejeck invite[
]Clear ban[
[Clear[ cancel
[Blockinvite[ on/off
]Mid @[
]Info @[
]Jumpbot[
[Kill 「@」[
]Kasih @[
[Unban 「@」[ By Tag
[Ban︎] Share Contact
[Unban︎[ Share Contact
]Baned @[
]dlmusic[
[Id[
]getlirik[
]getig[
]getimage[
]groupimage[
[Banlist︎[
[Cek ban[
[Invite:「mid」[
[Rename:「name」[
[gift[
[Respo︎n[
[Bot cancel[
[Clone @[
]Back[
]Pap @[
]Sc @[
]Sp @[
[Tagall[
[Mimic: on/off[
]Target @[
]Target Del @[
]Mimic list[

"""
#admin = [""]
mid = ['u05f4feb235542b74ef4538db57f2a0bd']
Amid = ki.getProfile().mid
#Bmid = kk.getProfile().mid
#Cmid = kc.getProfile().mid
KAC = [ki]
Bots = [mid,Amid]
responsename = cl.getProfile().displayName
responsename2 = ki.getProfile().displayName
#responsename3 = kk.getProfile().displayName
#responsename4 = kc.getProfile().displayName

wait = {
    'contact':False,
    'autoJoin':True,
    'autoCancel':{"on":True,"members":1},
    'leaveRoom':True,
    'timeline':True,
    'autoAdd':True,
    'message':"Thanks for add me",
    "lang":"JP",
    "comment":"Thanks for add me",
    "commentOn":False,
    "commentBlack":{},
    "wblack":False,
    "dblack":False,
    "clock":True,
    "Protectguest":False,
    "tag":True,
    "ProtectQR":False,
    "cName":"unknown",
    "blacklist":{},
    "winvite":False,
    "uppoto":False,
    "likefunction":False,
    "welcomemsg":False,
    "Reinvite":False,
    "wblacklist":False,
    "dblacklist":False,
    "protectionOn":True,
    "detectMention":True
    }

wait2 = {
    'readPoint':{},
    'readMember':{},
    'setTime':{},
    'ROM':{},
    'rom':{}
    }
setTime = {}
setTime = wait2['setTime']

contact = cl.getProfile()
backup = cl.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus


def cms(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","?","???:","???:","????","????"]
    for texX in tex:
        for command in commands:
            if string ==command:
                return True
    return False

def cmi(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","?","???:","???:","????","???:"]
    for texX in tex:
        for command in commands:
            if texX + command in string:
                return True
    return False
def yt(query):
    with requests.session() as s:
         isi = []
         if query == "":
             query = "S1B tanysyz"   
         s.headers['user-agent'] = 'Mozilla/5.0'
         url    = 'http://www.youtube.com/results'
         params = {'search_query': query}
         r    = s.get(url, params=params)
         soup = BeautifulSoup(r.content, 'html5lib')
         for a in soup.select('.yt-lockup-title > a[title]'):
            if '&list=' not in a['href']:
                if 'watch?v' in a['href']:
                    b = a['href'].replace('watch?v=', '')
                    isi += ['youtu.be' + b]
         return isi
def cmd(text, commands):
    for command in commands:
        if command in text:
            return True
    return False
def music(songname):
    params = {'songname':songname}
    url = 'http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params)
    r = requests.get(url,verify=False).text
    data = json.loads(r)
    for song in data:
        return song[4]
        
def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     #If the Current Version of Python is 3.0 or above
        import urllib,request    #urllib library for Extracting web pages
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        #If the Current Version of Python is 2.x
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

#Finding 'Next Image' from the given raw page
def _images_get_next_item(s):
    start_line = s.find('rg_di')
    if start_line == -1:    #If no links are found then give an error!
        end_quote = 0
        link = "no_links"
        return link, end_quote
    else:
        start_line = s.find('"class="rg_meta"')
        start_content = s.find('"ou"',start_line+90)
        end_content = s.find(',"ow"',start_content-90)
        content_raw = str(s[start_content+6:end_content-1])
        return content_raw, end_content

#Getting all links with the help of '_images_get_next_image'
def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      #Append all the links in the list named 'Links'
            time.sleep(0.1)        #Timer could be used to slow down the request for image downloads
            page = page[end_content:]
    return items

def mention(to, nama):
    aa = ""
    bb = ""
    strt = int(0)
    akh = int(0)
    nm = nama
    myid = cl.getProfile().mid
    if myid in nm:    
      nm.remove(myid)
    #print nm
    for mm in nm:
      akh = akh + 6
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 7
      akh = akh + 1
      bb += "@nrik \n"
    aa = (aa[:int(len(aa)-1)])
    text = bb
    try:
       cl.sendMessage(to, text, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
    except Exception as error:
       print(error)
 
def NOTIFIED_UPDATE_GROUP(op):
           if wait["ProtectQR"] == True:
               if op.param2 not in Bots:
                   G = cl.getGroup(op.param1)
                   ginfo = cl.getGroup(op.param1)
                   #G.preventedJoinByTicket = False
                   #cl.updateGroup(G)
                   #cl.kickoutFromGroup(op.param1,[op.param2])
                   #cl.updateGroup(G)
                   G.preventedJoinByTicket = True
                   cl.updateGroup(G)
                   return
               #sender = op.param2
               contact = cl.getContact(op.param1,[op.param2])
               msg.contentMetadata = {'mid': contact}
               cl.sendMessage(op.param1,'', msg.contentMetadata, 13)
               print ("Update group")
poll.addOpInterrupt(11,NOTIFIED_UPDATE_GROUP)

def NOTIFIED_INVITED_INTO_GROUP(op):
	      if wait["Protectguest"] == True:
               if op.param2 not in Bots:
                  cl.cancelGroupInvitation(op.param1,[op.param3])
poll.addOpInterrupt(13, NOTIFIED_INVITED_INTO_GROUP)
def NOTIFIED_LEAVE_GROUP(op):
	      if wait["Reinvite"] == True:
                try:
                    ki.inviteIntoGroup(op.param1, [op.param2])
                except:
                    random.choice(KAC).inviteIntoGroup(op.param1, [op.param2])
poll.addOpInterrupt(15, NOTIFIED_LEAVE_GROUP)

def NOTIFIED_ACCEPT_GROUP_INVITATION(op):
	if op.param2 in wait["blacklist"]:
                try:
                    cl.kickoutFromGroup(op.param1, op.param3)
                except:
                    random.choice(KAC).kickoutFromGroup(op.param1, op.param2)
poll.addOpInterrupt(17,NOTIFIED_ACCEPT_GROUP_INVITATION)
def NOTIFIED_READ_MESSAGE(op):
    try:
        if op.param1 in wait2['readPoint']:
            Name = cl.getContact(op.param2).displayName
            if Name in wait2['readMember'][op.param1]:
                pass
            else:
                wait2['readMember'][op.param1] += "\n・" + Name
                wait2['ROM'][op.param1][op.param2] = "・" + Name
        else:
            pass
    except:
        pass
poll.addOpInterrupt(55, NOTIFIED_READ_MESSAGE)
def RECEIVE_MESSAGE(op):
    msg = op.message
    try:
        if msg.contentType == 0:
            try:
                if msg.to in wait2['readPoint']:
                    if msg._from in wait2["ROM"][msg.to]:
                        del wait2["ROM"][msg.to][msg._from]
                else:
                    pass
            except:
                pass
        else:
            pass
    except KeyboardInterrupt:
	       sys.exit(0)
    except Exception as error:
        print (error)
        print ("\n\nRECEIVE_MESSAGE\n\n")
        return
def findMusic(to,song):
    params = {'songname':song}
    r = requests.get('https://ide.fdlrcn.com/workspace/yumi-apis/joox?'+urllib.urlencode(params))
    data = r.text
    data = data.encode('utf-8')
    data = json.loads(data)
    for song in data:
        ki.sendText(to,"This Your Music.\n\nJudul: " + song[0] + "\nWaktu: " + song[1] + "\nLink: " + song[3] + "\nDownload: " + song[4])
    

def findLyric(to,song):
    params = {'songname':song}
    r = requests.get('https://ide.fdlrcn.com/workspace/yumi-apis/joox?'+urllib.urlencode(params))
    data = r.text
    data = data.encode('utf-8')
    data = json.loads(data)
    for song in data:
        ki.sendText(to,"Lyrics Of " + song[0] + ":\n\n"+ song[5])

def RECEIVE_MESSAGE(op):
    '''
        This is sample for implement BOT in LINE group
        Invite your BOT to group, then BOT will auto accept your invitation
        Command availabe :
        > hi
        > /author
    '''
    msg = op.message
    
    text = msg.text
    msg_id = msg.id
    receiver = msg.to
    sender = msg.to
    
    try:
        # Check content only text message
        if msg.contentType == 0:
            # Check only group chat
            if msg.toType == 2:
                # Chat checked request
                cl.sendChatChecked(receiver, msg_id)
                # Get sender contact
                contact = cl.getContact(sender)
                # Command list
                if text.lower() == 'dol':
                    cl.log('[%s] %s' % (contact.displayName, text))
                    cl.sendMessage(receiver, 'yup say?')
                if "@"+cl.getProfile().displayName in msg.text:
                	tanya = msg.text.replace("@"+cl.getProfile().displayName,"")
                	jawab = ("woi "+cl.getContact(sender).displayName+"yup kak","yup say?"+cl.getContact(sender).displayName+" ada apa?")
                	jawaban = random.choice(jawab)
                	cl.sendMessage(msg.to,jawaban)
                	#contact = cl.getContact(sender)
                	#kc.kickoutFromGroup(msg.to, sender)	
                
                elif text.lower() == "fuck":
                	#target_ID = msg.to
                	random.choice(KAC).kickoutFromGroup(receiver, sender)
                elif text.lower() == "hai":
                	cl.sendImage(receiver, "hai.png")
                	print ("image >>>sended<<<")
                elif text.lower() == 'author':
                    cl.log('[%s] %s' % (contact.displayName, text))
                    cl.sendMessage(receiver, 'edoyveak')
    except Exception as e:
        cl.log("[RECEIVE_MESSAGE] ERROR : " + str(e))
  #Add function to LinePoll
poll.addOpInterruptWithDict({
    OpType.RECEIVE_MESSAGE: RECEIVE_MESSAGE
})
def SEND_MESSAGE(op):
    msg = op.message   
    text = msg.text
    msg_id = msg.id
    receiver = msg.to
  #  sender = msg.from_
    
    try:
        if msg.toType == 0:
            if msg.contentType == 0:
                if msg.text == "Mid":
                    cl.sendMessage(msg.to, msg.to)
                if msg.text == "itieue":
                    cl.sendMessage(msg.to,'', contentMetadata, 13)
                if msg.text == "Gift":
                    cl.sendMessage(msg.to, text="gift sent", contentMetadata=None, contentType=9)
                else:
                    pass
            else:
                pass
        if msg.toType == 2:
            if msg.contentType == 0:
                
                if msg.text == "Time":
                   cl.sendMessage(msg.to, "Sekarang " + datetime.datetime.today().strftime('Tanggal : %Y:%m:%d \nSekarang Jam : %H:%M:%S'))
        if msg.text is None:
            return
        if msg.contentType == 13:
               if wait["wblack"] == True:
                    if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        cl.sendMessage(msg.to,"already")
                        wait["wblack"] = False
                    else:
                        wait["commentBlack"][msg.contentMetadata["mid"]] = True
                        wait["wblack"] = False
                        cl.sendMessage(msg.to,"decided not to comment")

               elif wait["dblack"] == True:
                   if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        del wait["commentBlack"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"deleted")
                        wait["dblack"] = False

                   else:
                        wait["dblack"] = False
                        cl.sendMessage(msg.to,"It is not in the black list")
               elif wait["wblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendMessage(msg.to,"already")
                        wait["wblacklist"] = False
                   else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = False
                        cl.sendMessage(msg.to,"aded")

               elif wait["dblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"deleted")
                        wait["dblacklist"] = False

                   else:
                        wait["dblacklist"] = False
                        cl.sendMessage(msg.to,"It is not in the black list")
               if wait["uppoto"] == True:
                  #if msg.from_ in admin:
                        target = msg.contentMetadata["mid"]
                        contact = cl.getContact(target)
                        X = contact.displayName
                        profile = cl.getProfile()
                        profile.displayName = X
                        cl.updateProfile(profile)
                        cl.sendMessage(msg.to, "done")
                        P = contact.pictureStatus
                        cl.updateProfilePicture(P)
               if wait["winvite"] == True:
                     #if msg.from_ in admin:
                         _name = msg.contentMetadata["displayName"]
                         invite = msg.contentMetadata["mid"]
                         groups = cl.getGroup(msg.to)
                         groups = cl.getGroup(msg.to)
                         pending = groups.invitee
                         targets = []
                         for s in groups.members:
                             if _name in s.displayName:
                                 ki.sendMessage(msg.to,"-> " + _name + " udah d dlam\nplease cek!!!")
                                 break
                             elif invite in wait["blacklist"]:
                                 ki.sendMessage(msg.to,"Sorry, " + _name + " On Blacklist")
                                 ki.sendMessage(msg.to,"unban dulu vrohh !, \n➡Unban: " + invite)
                                 break
                             else:
                                 targets.append(invite)
                         if targets == []:
                             pass
                         else:
                             for target in targets:
                                 try:
                                     ki.findAndAddContactsByMid(target)
                                     ki.inviteIntoGroup(msg.to,[target])
                                     ki.sendMessage(msg.to,"done vrohh \n➡" + _name +"\n Telah tercyduk....😉")
                                     wait["winvite"] = False
                                     break
                                 except:
                                     try:
                                         ki.findAndAddContactsByMid(invite)
                                         ki.inviteIntoGroup(op.param1,[invite])
                                         wait["winvite"] = False
                                     except:
                                         try:
                                             ki.findAndAddContactsByMid(invite)
                                             ki.inviteIntoGroup(op.param1,[invite])
                                             wait["winvite"] = False
                                             ki.sendMessage(msg.to,"done vrohh...\n➡" + _name)
                                             break
                                         except:
                                            try:
                                                 cl.findAndAddContactsByMid(invite)
                                                 cl.inviteIntoGroup(op.param1,[invite])
                                                 wait["winvite"] = False
                                                 cl.sendMessage(msg.to,"done vroh\n➡" + _name)
                                                 break
                                            except:
                                                 ki.sendMessage(msg.to,"Negative, Error detected")
                                                 wait["winvite"] = False
                                                 break

               elif wait["contact"] == True:
                    msg.contentType = 0
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendMessage(msg.to,"「 Name 」 :\n" + msg.contentMetadata["displayName"] + "\n「 Mid 」 :\n" + msg.contentMetadata["mid"] + "\n「 Status 」 :\n" + contact.statusMessage + "\n「 Profile 」 :\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n「 Cover 」 :\n" + str(cu))
                    else:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendMessage(msg.to,"「 Name 」 :\n" + contact.displayName + "\n「 Mid 」 :\n" + msg.contentMetadata["mid"] + "\n「 Status 」 :\n" + contact.statusMessage + "\n「 Profile 」 :\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n「 Cover 」 :\n" + str(cu))
                        
               elif msg.contentType == 16:
                if wait["timeline"] == True:
                    msg.contentType = 0
                    if wait["lang"] == "JP":
                        msg.text = "post URL\n" + msg.contentMetadata["postEndUrl"]
                    else:
                        msg.text = "URLâ†’\n" + msg.contentMetadata["postEndUrl"]
                    cl.sendMessage(msg.to,msg.text)
                    
        elif msg.text is None:
                return
        elif msg.text in ["Key","help","Help"]:
     #          if msg.from_ in admin:
                if wait["lang"] == "JP":
                    cl.sendMessage(msg.to,helpMessage)
                else:
                    cl.sendMessage(msg.to,helpt)
        elif text.lower() == 'hi':
            contact = cl.getContact(sender)
            cl.log('[%s] %s' % (contact.displayName, text))
            cl.sendMessage(msg.to, 'Hi too! How are you?')
        elif "Pap @" in msg.text:          
                   _name = msg.text.replace("Pap @","")
                   _nametarget = _name.rstrip('  ')
                   gs = cl.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       cl.sendMessage(msg.to,"Contact not found")
                   else:
                       for target in targets:
                           try:
                               contact = cl.getContact(target)
                               path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                               cl.sendImageWithURL(msg.to, path)
                           except:
                               pass 
        elif "Clone @" in msg.text:
                     _name = msg.text.replace("Clone @","")
                     _nametarget = _name.rstrip('  ')
                     gs = cl.getGroup(msg.to)
                     targets = []
                     for g in gs.members:
                         if _nametarget == g.displayName:
                             targets.append(g.mid)
                     if targets == []:
                         cl.sendMessage(msg.to, "Target Not Found")
                     else:
                         for target in targets:
                             try:
                                cl.cloneContactProfile(target)
                                cl.sendMessage(msg.to, "Succes")
                             except Exception as error:
                                 print (error)
        
        elif msg.text in ["Clear"]:
 #              if msg.from_ in mid: 
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.invitee]
                    for _mid in gMembMids:
                        cl.cancelGroupInvitation(msg.to,[_mid])
                    cl.sendMessage(msg.to,"I pretended to cancel and canceled.")
        elif msg.text in ["Sp","Speed","speed"]:
                start = time.time()
                cl.sendMessage(msg.to, "Progress...")
                elapsed_time = time.time() - start
                cl.sendMessage(msg.to, "%sseconds" % (elapsed_time))   
        elif msg.text in ["Back"]:
                    try:
               	      
               	      cl.updateProfilePicture(backup.pictureStatus)
               	      cl.updateProfile(backup)
               	      cl.sendMessage(msg.to, "Profile telah kembali...")
                    except Exception as e:
                       cl.sendMessage(msg.to, str(e))
                       
        elif 'scover' in text.lower():
                                try:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    u = key["MENTIONEES"][0]["M"]
                                    a = cl.getProfileCoverURL(mid=u)
                                    print(a)
                                    cl.sendImageWithURL(receiver, a)
                                except Exception as e:
                                    print(e)
        elif text.lower() == 'author':
            contact = cl.getContact(sender)
            cl.log('[%s] %s' % (contact.displayName, text))
            cl.sendMessage(msg.to, 'edoyveak')            
        elif text.lower() == "responsename":
            cl.sendMessage(msg.to,responsename)
            ki.sendMessage(msg.to,responsename2)
            #kk.sendMessage(msg.to,responsename3)
            #kc.sendMessage(msg.to,responsename4)
            #km.sendMessage(msg.to,responsename5)
        elif "Mid @" in msg.text:
                _name = msg.text.replace("Mid @","")
                _nametarget = _name.rstrip(' ')
                gs = cl.getGroup(msg.to)
                for g in gs.members:
                    if _nametarget == g.displayName:
                        cl.sendMessage(msg.to, g.mid)
                    else:
                        pass
        elif "Removed" in msg.text:
               #if msg.from_ in mid:
                  try:
                     cl.removeAllMessages(op.param2)
                     cl.sendMessage(msg.to, " all pesan telah di hapus")
                     print ("sukses hapus")
                  except:
                      pass
        if msg.text.lower() == 'Kickall':
        	a = []
        	b = cl.getGroup(msg.to)
        	for i in b:
        		if i.mid not in Bots:
        			a.append(i.mid)
        			for c in a:
        				try: random.choice(KAC).kickoutFromGroup(msg.to,[c])
        				except:
        					random.choice(KAC).kickoutFromGroup(msg.to,[c])
        					cl.sendMessage(msg.to,"Done!")
        if text == 'server':
           a="lscpu | grep -i 'model name'|awk -F : '{print $2}'"
           b="lscpu | grep -i 'architecture' | awk -F : '{print $2}'"
           c="cat /etc/redhat-release"
           d="lsblk | awk '{print $4}' | head -2 | tail -1"
           e="free -lm | awk '{print $2}'| head -2|tail -1"
           g="lscpu | grep -i 'virtualization' | awk -F : '{print $2}'"
           h="lscpu | grep -i 'CPU op-mode' | awk -F : '{print $2}'"
           cmdlis = [a,b,c,d,e,g,h]
           lis = "Server\n\n"
           for i in cmdlis:
                c=cmd.getoutput(i)
                lis += c.strip()+"\n"
           cl.sendMessage(receiver, lis)
         
        elif ("Pancal " in msg.text):
 #              if msg.from_ in admin:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"] [0] ["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           cl.kickoutFromGroup(msg.to,[target])
                       except:
                           cl.sendMessage(msg.to,"Error")
        elif msg.text in ["Uppoto"]:
            	#if msg.from_ in admin:
                 wait["uppoto"] = True
                 cl.sendMessage(msg.to,"send contact 😉")
        elif msg.text in ["Jepit"]:
     #       	if msg.from_ in admin:
                 wait["winvite"] = True
                 cl.sendMessage(msg.to,"send contact 😉")
        elif "Usir " in msg.text:
   #               if msg.from_ in admin:
                       ulti0 = msg.text.replace("Usir ","")
                       ulti1 = ulti0.lstrip()
                       ulti2 = ulti1.replace("@","")
                       ulti3 = ulti2.rstrip()
                       _name = ulti3
                       gs = cl.getGroup(msg.to)
                       ginfo = cl.getGroup(msg.to)
                       gs.preventedJoinByTicket = False
                       cl.updateGroup(gs)
                       #gs.preventedJoinByTicket(gs)
                       #cl.updateGroup(gs)
                       invsend = 0
                       Ticket = cl.reissueGroupTicket(msg.to)
                       ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                       time.sleep(0.1)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           cl.sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    ki.kickoutFromGroup(msg.to,[target])
                                    print (msg.to,[g.mid])
                                except:
                                    ki.sendMessage(msg.to,"TerCYDUC Vrohh")
                                    ki.sendMessage(msg.to,"Done, See u :*")
                                    ki.leaveGroup(msg.to)
                                    G = cl.getGroup(msg.to)
                                    G.preventedJoinByTicket = True
                                cl.updateGroup(G)
                                G.preventedJoinByTicket(G)
                                cl.updateGroup(G)
        elif msg.text in ["Reject invite"]:
                    gid = cl.getGroupIdsInvited()
                    for i in gid:
                        cl.rejectGroupInvitation(i)
                    if wait["lang"] == "JP":
                        cl.sendMessage(msg.to,"All invitations have been rejected")
                    else:
                        cl.sendMessage(msg.to,"Done")
        elif "point" == msg.text.lower():
                if msg.to in wait2['readPoint']:
                        try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                            del wait2['setTime'][msg.to]
                        except:
                            pass
                        wait2['readPoint'][msg.to] = msg.id
                        wait2['readMember'][msg.to] = ""
                        wait2['setTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                        wait2['ROM'][msg.to] = {}
                        with open('sider.json', 'w') as fp:
                         json.dump(wait2, fp, sort_keys=True, indent=4)
                         cl.sendText(msg.to,"cctv already on")
                else:
                    try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                            del wait2['setTime'][msg.to]
                    except:
                          pass
                    wait2['readPoint'][msg.to] = msg.id
                    wait2['readMember'][msg.to] = ""
                    wait2['setTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                    wait2['ROM'][msg.to] = {}
                    with open('sider.json', 'w') as fp:
                     json.dump(wait2, fp, sort_keys=True, indent=4)
                     cl.sendText(msg.to, "Set reading point:\n" + datetime.now().strftime('%H:%M:%S'))
                     print (wait2)
        elif "cctv off" == msg.text.lower():
                if msg.to not in wait2['readPoint']:
                    cl.sendText(msg.to,"cctv already off")
                else:
                    try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                            del wait2['setTime'][msg.to]
                    except:
                          pass
                    cl.sendText(msg.to, "Delete reading point:\n" + datetime.now().strftime('%H:%M:%S'))


                    
        elif "sider" == msg.text.lower():
                    if msg.to in wait2['readPoint']:
                        if wait2["ROM"][msg.to].items() == []:
                             cl.sendText(msg.to, "Sider:\nNone")
                        else:
                            chiya = []
                            for rom in wait2["ROM"][msg.to].items():
                                chiya.append(rom[1])
                               
                            cmem = cl.getContacts(chiya)
                            zx = ""
                            zxc = ""
                            zx2 = []
                            xpesan = 'Sider:\n'
                        for x in range(len(cmem)):
                                xname = str(cmem[x].displayName)
                                pesan = ''
                                pesan2 = pesan+"@a\n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':cmem[x].mid}
                                zx2.append(zx)
                                zxc += pesan2
                                msg.contentType = 0
           
                        print( zxc)
                        msg.text = xpesan+ zxc + "\ncctving time: %s\nCurrent time: %s"%(wait2['setTime'][msg.to],datetime.now().strftime('%H:%M:%S'))
                        lol ={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                        print (lol)
                        msg.contentMetadata = lol
                        try:
                          cl.sendMessage(msg)
                        except Exception as error:
                              print (error)
                        pass
               
           
                    else:
                        cl.sendText(msg.to, "Cctv has not been set.")
        elif "Call " in msg.text:
              #if msg.from_ in admin:
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                targets = []
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for target in targets:
                   try:
                      cl.acquireCallRoute([target])
                   except:
                      pass
        elif msg.text in ["Me"]:
                msg.contentType = 13
                msg.contentMetadata = {'mid': msg.from_}
                cl.sendMessage(msg.to,'', contentMetadata,13)
        elif msg.text.lower() in ["upot on"]:
                #if msg.from_ in admin:
                    if wait["uppoto"] == True:
                        if wait["lang"] == "JP":
                            cl.sendMessage(msg.to,"uppoto ON😉")
                        else:
                            cl.sendMessage(msg.to,"uppoto on😉")
                    else:
                        wait["uppoto"] = True
                        if wait["lang"] == "JP":
                            cl.sendMessage(msg.to,"uppoto already on")
                        else:
                            cl.sendMessage(msg.to,"already on")
        elif msg.text.lower() in ["upot off"]:
                #if msg.from_ in admin:
                    if wait["uppoto"] == False:
                        if wait["lang"] == "JP":
                            cl.sendMessage(msg.to,"upoto off...*-* ")
                        else:
                            cl.sendMessage(msg.to,"uppoto off")
                    else:
                        wait["uppoto"] = False
                        if wait["lang"] == "JP":
                            cl.sendMessage(msg.to,"uppoto already off")
                        else:
                            cl.sendMessage(msg.to,"uppoto off")
        elif msg.text in ["Banlist"]:
     #          if msg.from_ in mid:
                if wait["blacklist"] == {}:
                    cl.sendMessage(msg.to,"nothing")
                    ki.sendText(msg.to,"nothing")
                    kk.sendText(msg.to,"nothing")
                    kc.sendText(msg.to,"nothing")
                else:
                    cl.sendMessage(msg.to,"Blacklist user")
                    mc = ""
                    for mi_d in wait["blacklist"]:
                        mc += "->" +cl.getContact(mi_d).displayName + "\n"
                    cl.sendMessage(msg.to,mc)
        elif ("Baned " in msg.text):
        #      if msg.from_ in admin:
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                targets = []
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for target in targets:
                   try:
                      wait["blacklist"][target] = True
                      f=codecs.open('st2__b.json','w','utf-8')
                      json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                      cl.sendMessage(msg.to,"Succes Banned")
                   except:
                      pass
            
        elif "Block @" in msg.text:
                if msg.toType == 2:
                    print ("[block] OK")
                    _name = msg.text.replace("Block @","")
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                           targets.append(g.mid)
                    if targets == []:
                        cl.sendMessage(msg.to, "Not Found...")
                    else:
                        for target in targets:
                            try:
                               cl.blockContact(target)
                               cl.sendMessage(msg.to, "Success block contact~")
                            except Exception as e:
                               print (e)
        elif msg.text in["Blocklist"]:
                blockedlist = cl.getBlockedContactIds()
                cl.sendMessage(msg.to, "Please wait...")
                kontak = cl.getContacts(blockedlist)
                num=1
                msgs="User Blocked List\n"
                for ids in kontak:
                    msgs+="\n%i. %s" % (num, ids.displayName)
                    num=(num+1)
                msgs+="\n\nTotal %i blocked user(s)" % len(kontak)
                cl.sendMessage(msg.to, msgs)
        elif msg.text in ["Clear ban"]:
              # if msg.from_ in mid:
                wait["blacklist"] = {}
                cl.sendMessage(msg.to, "all banlist removed😉")
        elif msg.text in ["Blockinvite on"]:
                if wait["Protectguest"] == True:
                    if wait["lang"] == "JP":
                        cl.sendMessage(msg.to,"done.....")
                    else:
                        cl.sendMessage(msg.to,"done")
                else:
                    wait["Protectguest"] = True
                    if wait["lang"] == "JP":
                        cl.sendMessage(msg.to,"Done.....")
                    else:
                        cl.sendMessage(msg.to,"done")
        elif msg.text in ["Blockinvite off"]:
                if wait["Protectguest"] == False:
                    if wait["lang"] == "JP":
                        cl.sendMessage(msg.to,"protect Off")
                    else:
                        cl.sendMessage(msg.to,"done")
                else:
                    wait["Protectguest"] = False
                    if wait["lang"] == "JP":
                        cl.sendMessage(msg.to,"protect Off")
                    else:
                        cl.sendMessage(msg.to,"done")
        elif msg.text in ["Protect on"]:
      #        if msg.from_ in admin:
                if wait["ProtectQR"] == True:
                    if wait["lang"] == "JP":
                        cl.sendMessage(msg.to,"Please...do not open qr!!!")
                    else:
                        cl.sendMessage(msg.to,"done")
                else:
                    wait["ProtectQR"] = True
                    if wait["lang"] == "JP":
                        cl.sendMessage(msg.to,"Please...do not open qr!!")
                    else:
                        cl.sendMessage(msg.to,"done")
        elif msg.text in ["Protect off"]:
#              if msg.from_ in admin:
                if wait["ProtectQR"] == False:
                    if wait["lang"] == "JP":
                        cl.sendMessage(msg.to,"Free....update group")
                    else:
                        cl.sendMessage(msg.to,"done")
                else:
                    wait["ProtectQR"] = False
                    if wait["lang"] == "JP":
                        cl.sendMessage(msg.to,"Free....update group")
                    else:
                        cl.sendMessage(msg.to,"done")
        elif msg.text in ["Rein on","invite on"]:
                if wait["Reinvite"] == True:
                    if wait["lang"] == "JP":
                        cl.sendMessage(msg.to,"awas limit😂")
                        #print "[Command]Join on executed"
                    else:
                        ki.sendMessage(msg.to,"awas limit...")
                        #print "[Command]Join on executed"
                else:
                    wait["Reinvite"] = True
                    if wait["lang"] == "JP":
                        cl.sendMessage(msg.to,"Auto Rein om")
                        print ("[Command]Join on executed")
                    else:
                        cl.sendMessage(msg.to,"gagal.....")
        elif msg.text in ["Rein off","invite off"]:
                if wait["Reinvite"] == False:
                    if wait["lang"] == "JP":
                        cl.sendMessage(msg.to,"Reinvite Off")
                        #print "[Command]Join off executed"
                    else:
                        cl.sendMessage(msg.to,"Auto Rein Off")
                        #print "[Command]Join off executed"
                else:
                    wait["Reinvite"] = False
                    if wait["lang"] == "JP":
                        cl.sendMessage(msg.to,"Done...")
                        #print "[Command]Join off executed"
                    else:
                        cl.senMessage(msg.to,"Done.....")
        elif msg.text.lower() in ["winvite on"]:
                #if msg.from_ in admin:
                    if wait["winvite"] == True:
                        if wait["lang"] == "JP":
                            cl.sendMessage(msg.to,"winvite ON😉")
                        else:
                            cl.sendMessage(msg.to,"Winvite on😉")
                    else:
                        wait["winvite"] = True
                        if wait["lang"] == "JP":
                            cl.sendMessage(msg.to,"Winvite already on")
                        else:
                            cl.sendMessage(msg.to,"already on")
        elif msg.text.lower() in ["winvite off"]:
                #if msg.from_ in admin:
                    if wait["winvite"] == False:
                        if wait["lang"] == "JP":
                            cl.sendMessage(msg.to,"winvite off...*-* ")
                        else:
                            cl.sendMessage(msg.to,"winvite off")
                    else:
                        wait["winvite"] = False
                        if wait["lang"] == "JP":
                            cl.sendMessage(msg.to,"winvite already off")
                        else:
                            cl.sendMessage(msg.to,"winvite off")
        elif msg.text in ["Set"]:
                md = ""
                if wait["uppoto"] == True: md+="[*] Upfoto : on\n"
                else: md+=" Upfoto : off\n"
                if wait["Reinvite"] == True: md+="[*] Reinvite : on\n"
                else: md+=" Reinvite : off\n"
                if wait["Protectguest"] == True: md+="[*] Block Invite on\n"
                else: md+="Block Invite off\n"
                if wait["winvite"] == True: md+="[*] Winvite : on\n"
                else: md+="[*] Winvite : off\n"
                if wait["ProtectQR"] == True: md+="[*] Protect Qr on\n"
                else: md+="Protect qr off\n"
                if wait["contact"] == True: md+="[*] Contact : on\n"
                else: md+=" Contact : off\n"
                if wait["autoJoin"] == True: md+="[*] Auto join : on\n"
                else: md +=" Auto join : off\n"
                if wait["autoCancel"]["on"] == True:md+="[*] Group cancel :" + str(wait["autoCancel"]["members"]) + "\n"
                else: md+= " Group cancel : off\n"
                if wait["leaveRoom"] == True: md+="[*] Auto leave : on\n"
                else: md+=" Auto leave : off\n"
                if wait["timeline"] == True: md+="[*] Share : on\n"
                else:md+=" Share : off\n"
                if wait["autoAdd"] == True: md+="[*] Auto add : on\n"
                else:md+=" Auto add : off\n"
                if wait["commentOn"] == True: md+="[*] Comment : on\n"
                else:md+="[*] Comment : off\n"
                cl.sendMessage(msg.to,md)
        elif msg.text == "me":
                    contentMetadata = {'mid': msg.from_}
                    cl.sendMessage(msg.to, '', contentMetadata, 13)
        elif msg.text in ["Jam off"]:
                if wait["clock"] == False:
                    cl.sendMessage(msg.to,"already off")
                else:
                    wait["clock"] = False
                    cl.sendMessage(msg.to,"done")
        elif msg.text.lower() == "blank":
                    msg.contentMetadata = {'mid': msg.to+"',"}
                    cl.sendMessage(msg.to ,'', msg.contentMetadata, 13)
        elif 'cover' in text.lower():
                                try:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    u = key["MENTIONEES"][0]["M"]
                                    a = cl.getProfileCoverURL(mid=u)
                                    print(a)
                                    cl.sendImageWithURL(receiver, a)
                                except Exception as e:
                                    print(e)
        elif text.lower() == 'tagall':
                                group = cl.getGroup(msg.to)
                                nama = [contact.mid for contact in group.members]
                                nm1, nm2, nm3, jml = [], [], [], len(nama)
                                if jml <= 100:
                                    mention(msg.to, nama)
                                if jml > 100 and jml < 200:
                                    for i in range(0, 100):
                                        nm1 += [nama[i]]
                                    mention(msg.to, nm1)
                                    for j in range(101, len(nama)):
                                        nm2 += [nama[j]]
                                    mention(msg.to, nm2)
                                if jml > 200 and jml < 300:
                                    for i in range(0, 100):
                                        nm1 += [nama[i]]
                                    mention(msg.to, nm1)
                                    for j in range(101, 200):
                                        nm2 += [nama[j]]
                                    mention(msg.to, nm2)
                                    for k in range(201, len(nama)):
                                        nm3 += [nama[k]]
                                    mention(msg.to, nm3)
                                if jml > 300:
                                    print("Waow,,300+ member")
                                #cl.sendMessage(receiver, "Members :"+str(jml))
        elif "image " in msg.text:
                search = msg.text.replace("image ","")
                url = 'https://www.google.com/search?espv=2&biw=1366&bih=667&tbm=isch&oq=kuc&aqs=mobile-gws-lite.0.0l5&q=' + search
                raw_html = (download_page(url))
                items = []
                items = items + (_images_get_all_items(raw_html))
                path = random.choice(items)
                print (path)
                try:
                    cl.sendImageWithURL(msg.to,path)
                except:
                    pass
        elif 'lirik ' in msg.text.lower():
                try:
                    songname = msg.text.lower().replace('lirik ','')
                    params = {'songname': songname}
                    r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                    data = r.text
                    data = json.loads(data)
                    for song in data:
                        hasil = 'Lyric Lagu ('
                        hasil += song[0]
                        hasil += ')\n\n'
                        hasil += song[5]
                        cl.sendMessage(msg.to, hasil)
                except Exception as wak:
                        cl.sendMessage(msg.to, str(wak))
        elif 'music ' in msg.text.lower():
                try:
                    songname = msg.text.lower().replace('music ','')
                    params = {'songname': songname}
                    r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                    data = r.text
                    data = json.loads(data)
                    for song in data:
                        hasil = 'This is Your Music\n'
                        hasil += 'Judul : ' + song[0]
                        hasil += '\nDurasi : ' + song[1]
                        hasil += '\nLink Download : ' + song[4]
                        cl.sendMessage(msg.to, hasil)
                        cl.sendMessage(msg.to, "Please Wait for audio...")
                        cl.sendAudioWithURL(msg.to, song[4])
                except Exception as njer:
                	cl.sendMessage(msg.to, str(njer))
        elif "Zodiak " in msg.text:
                tanggal = msg.text.replace("Zodiak ","")
                r=requests.get('https://script.google.com/macros/exec?service=AKfycbw7gKzP-WYV2F5mc9RaR7yE3Ve1yN91Tjs91hp_jHSE02dSv9w&nama=ervan&tanggal='+tanggal)
                data=r.text
                data=json.loads(data)
                lahir = data["data"]["lahir"]
                usia = data["data"]["usia"]
                ultah = data["data"]["ultah"]
                zodiak = data["data"]["zodiak"]
                cl.sendMessage(msg.to,"Tanggal Lahir: "+lahir+"\n\nUsia: "+usia+"\n\nUltah: "+ultah+"\n\nZodiak: "+zodiak)
        elif "ts " in msg.text.lower():
                say = msg.text.lower().replace("ts ","")
                lang = 'id'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")
        elif msg.text in ["Mayhem"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    print ("ok")
                    _name = msg.text.replace("Mayhem","")
                    gs = cl.getGroup(msg.to)
                    gs = kk.getGroup(msg.to)
                    gs = kc.getGroup(msg.to)
                    #gs = kr.getGroup(msg.to)
                    gs = ki.getGroup(msg.to)
                    cl.sendMessage(msg.to,"「 Mayhem 」\nMayhem is STARTING♪\n' abort' to abort♪")
                    ki.sendMessage(msg.to,"「 Mayhem 」\n46 victims shall yell hul·la·ba·loo♪\nˌ/hələbəˈlo͞o,ˈhələbəˌlo͞o/")
                    targets = []
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendMessage(msg.to,"Tidak ditemukan")
                    else:
                        for target in targets:
                            if not target in Bots:
                                try:
                                   klist=[ki,cl]
                                   kicker=random.choice(klist)
                                   kicker.kickoutFromGroup(msg.to,[target])
                                   print (msg.to,[g.mid])
                                except:
                                  ki.sendMessage(msg.to,"Mayhem done")
        elif "Backup" in msg.text:
        	try:
        		cl.updateDisplayPicture(backup.pictureStatus)
        		cl.updateProfile(profile)
        		cl.sendMessage(msg.to, "Success backup profile")
        	except Exception as e:
        			cl.sendMessage(msg.to, str(e))
        elif "Unban " in msg.text:
    #            if msg.from_ in staff:
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    targets = []
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            del wait["blacklist"][target]
                            f=codecs.open('st2__b.json','w','utf-8')
                            json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendMessage(msg.to,"Done Unbanned")
                            print ("[Command] Unbannad")
                        except:
                            pass
        
                
        elif msg.text in ["Conban","Contactban","Contact ban"]:
                if wait["blacklist"] == {}:
                    cl.sendMessage(msg.to,"Tidak Ada Blacklist")
                else:
                    cl.sendMessage(msg.to,"Daftar Blacklist")
                    h = ""
                    for i in wait["blacklist"]:
                        h = cl.getContact(i)
                        contentMetadata = {'mid': i}
                        cl.sendMessage(msg.to, '', contentMetadata, 13)
        elif text.lower() in ["bye"]:
               ki.leaveGroup(msg.to)
               kk.leaveGroup(msg.to)
               kc.leaveGroup(msg.to)
               
        elif text.lower() in ["aple"]:
                G = cl.getGroup(msg.to)
                ginfo = cl.getGroup(msg.to)
                G.preventedJoinByTicket = False
                cl.updateGroup(G)
                invsend = 0
                Ticket = cl.reissueGroupTicket(msg.to)
                ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                kk.acceptGroupInvitationByTicket(msg.to,Ticket)
                kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                
                G = cl.getGroup(msg.to)
                G.preventedJoinByTicket = True
                cl.updateGroup(G)
                G.preventedJoinByTicket(G)
                cl.updateGroup(G)
    except Exception as e:
        cl.log("[SEND_MESSAGE] ERROR : " + str(e))
    
# Auto join if BOT invited to group
def NOTIFIED_INVITE_INTO_GROUP(op):
    try:
        cl.acceptGroupInvitation(op.param1)
        ki.acceptGroupInvitation(op.param1)
        kk.acceptGroupInvitation(op.param1)
        kc.acceptGroupInvitation(op.param1)
    except Exception as e:
        cl.log("[NOTIFIED_INVITE_INTO_GROUP] ERROR : " + str(e))

def NOTIFIED_KICKOUT_FROM_GROUP(op):
    try:
        if op.param3 in Bots:
            if op.param2 not in mid:
            		try:
            			G = cl.getGroup(op.param1)
            			#cl.kickoutFromGroup(op.param1,[op.param2])
            			G.preventedJoinByTicket = False
            			cl.updateGroup(G)
            			invsend = 0
            			Ticket = cl.reissueGroupTicket(op.param1)
            			cl.acceptGroupInvitationByTicket(op.param1,Ticket)
            			time.sleep(0.01)
            			ki.acceptGroupInvitationByTicket(op.param1,Ticket)
            			time.sleep(0.01)
            			kk.acceptGroupInvitationByTicket(op.param1,Ticket)
            			time.sleep(0.01)
            			kc.acceptGroupInvitationByTicket(op.param1,Ticket)
            			time.sleep(0.01)
            			G.preventedJoinByTicket = True
            			cl.updateGroup(G)
            			wait["blacklist"][op.param2] = True
            		except:
            			G = random.choice(KAC).getGroup(op.param1)
            			#kc.kickoutFromGroup(op.param1,[op.param2])
            			G.preventedJoinByTicket = False
            			kc.updateGroup(G)
            			invsend = 0
            			Ticket = kc.reissueGroupTicket(op.param1)
            			cl.acceptGroupInvitationByTicket(op.param1,Ticket)
            			time.sleep(0.01)
            			ki.acceptGroupInvitationByTicket(op.param1,Ticket)
            			time.sleep(0.01)
            			kk.acceptGroupInvitationByTicket(op.param1,Ticket)
            			time.sleep(0.01)
            			kc.acceptGroupInvitationByTicket(op.param1,Ticket)
            			time.sleep(0.01)
            			G.preventedJoinByTicket = True
            			random.choice(KAC).updateGroup(G)
            			wait["blacklist"][op.param2] = True
    except Exception as e:
        cl.log("[SEND_MESSAGE] ERROR : " + str(e))
              #cl.log("[NOTIFIED_KICKOUT_FROM_GROUP]
# Add function to LinePoll
poll.addOpInterruptWithDict({
    #OpType.RECEIVE_MESSAGE: RECEIVE_MESSAGE,
    OpType.SEND_MESSAGE: SEND_MESSAGE,
    OpType.NOTIFIED_KICKOUT_FROM_GROUP: NOTIFIED_KICKOUT_FROM_GROUP,
    OpType.NOTIFIED_INVITE_INTO_GROUP: NOTIFIED_INVITE_INTO_GROUP
})


while True:
 poll.trace()

