# SEMUA AKAN MATI PADA  WAKTUNYA
BOT PROTECT PY3 ANTI JS V2 LINE🐦FIXS UPDATE 19 AGUSTUS 2018
------
GET TOKEN :
------
- `Google Chrome`
- `http://101.255.95.249:6969`
-
Cara Install Bot :
------
HEADER CHROME

C9 SERVER/ VPS :
- `sudo apt-get update -y`
- `sudo apt-get install git -y`
- `sudo apt-get install python3-pip -y`
- `sudo pip3 install rsa`
- `sudo pip3 install thrift==0.11.0`
- `sudo pip3 install requests`
- `sudo pip3 install pytz`
- `sudo pip3 install bs4`
- `sudo pip3 install gtts`
- `sudo pip3 install googletrans`
- `sudo pip3 install humanfriendly`
- `sudo pip3 install goslate`
- `sudo pip3 install pafy`
- `sudo pip3 install wikipedia`
- `sudo pip3 install tweepy`
- `sudo pip3 install youtube_dl`
- `git clone https://github.com/PHIEZUKE/ANTIJS`
- `cd ANTIJS`
- `python JSNON.py`

INSTALL Di TERMUX :
- `pkg update`
- `pkg install git`
- `pkg install python3-pip`
- `pip3 install rsa`
- `pip3 install thrift==0.11.0`
- `pip3 install requests`
- `pip3 install bs4`
- `pip3 install gtts`
- `pip3 install beautifulsoup`
- `pip3 install googletrans`
- `pip3 install pafy`
- `pip3 install humanfriendly`
- `pip3 install goslate`
- `pip3 install wikipedia`
- `pip3 install youtube_dl`
- `pip3 install tweepy`
- `git clone https://github.com/PHIEZUKE/ANTIJS`
- `cd ANTIJS`
- `python3 JSNON.py`

Cara Menjalankan Bot Kembali :
------
Di C9 :
- `cd ANTIJS`
- `python3 JSNON.py`

Di Termux :
- `cd ANTIJS`
- `python3 JSNON.py`


UPLOADED BY CALON ALMARHUM
------
- `Add My ID LINE : calon_almarhum99 😂`
- `Sambil nonton youtue biar cepet paham yang blom tau. dulu aku juga gitu 😊. Youtube me : PHIEZUKE2`
#cuma saran bukan menggurui 😅
#aku juga masih pekok kuadrat😊

Thx To : ALLOH SWT & All
------
- `SALAM HORMAT BUAT PARA MASTAH SEMUANYA 😅 `
